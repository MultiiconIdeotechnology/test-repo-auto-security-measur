import { Routes } from "@angular/router";
import { BusBookingDetailsComponent } from "./bus-booking-details/bus-booking-details.component";
import { BusComponent } from "./bus.component";

export default [
    {
        path: '',
        component: BusComponent
    },
    {
        path: 'details',
        component: BusBookingDetailsComponent
    },
    {
        path: 'details/:id',
        component: BusBookingDetailsComponent
    }
] as Routes

