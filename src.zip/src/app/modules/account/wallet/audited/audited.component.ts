import { NgIf, NgFor, NgClass, DatePipe, AsyncPipe, CommonModule } from '@angular/common';
import { Component, OnDestroy, ViewChild } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterModule } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AppConfig } from 'app/config/app-config';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { MasterService } from 'app/services/master.service';
import { ToasterService } from 'app/services/toaster.service';
import { WalletService } from 'app/services/wallet.service';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { Subject, takeUntil, debounceTime } from 'rxjs';
import { InfoWalletComponent } from '../info-wallet/info-wallet.component';
import { WalletFilterComponent } from '../wallet-filter/wallet-filter.component';

@Component({
  selector: 'app-audited',
  templateUrl: './audited.component.html',
  styleUrls: ['./audited.component.scss'],
  styles: [`
  .tbl-grid {
    grid-template-columns: 40px 200px 190px 160px 150px 130px 190px;
  }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatProgressBarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatMenuModule,
    MatDialogModule,
    MatTooltipModule,
    MatDividerModule,
    CommonModule,
    MatTabsModule

  ],
})
export class AuditedComponent {

  @ViewChild('tabGroup') tabGroup;

  @ViewChild(MatPaginator) public _paginatorPending: MatPaginator;
  @ViewChild(MatSort) public _sortPending: MatSort;
  searchInputControlAudit = new FormControl('');

  public key: any;
  public sortColumn: any;
  public sortDirection: any;
  Mainmodule: any;
  isLoading = false;
  public _unsubscribeAll: Subject<any> = new Subject<any>();

  module_name = module_name.wallet
  dataList = [];
  total = 0;
  appConfig = AppConfig;
  data:any

  columns = [
    { key: 'reference_number', name: 'Reference Number', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, tooltip: true },
    { key: 'recharge_for_name', name: 'Recharge For', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false, tooltip: true },
    { key: 'request_date_time', name: 'Request Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'recharge_amount', name: 'Recharge Amount', is_date: false, date_formate: '', is_sortable: true, class: 'header-right-view', is_sticky: false, align: '', indicator: false },
    { key: 'filename', name: 'Attachment', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false, isicon: true },
    { key: 'mop', name: 'Mode Of Payment', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },

  ]
  cols = [];

  protected masterService: MasterService;


  constructor(
    private walletService: WalletService,
    private conformationService: FuseConfirmationService,
    private alertService: ToasterService,
    private matDialog: MatDialog,
  ) {
    // super(module_name.wallet)
    this.cols = this.columns.map(x => x.key);
    this.key = this.module_name;
    this.sortColumn = 'recharge_for_name';
    this.sortDirection = 'asc';
    this.Mainmodule = this
 
  }

  ngOnInit(): void {

    // this.searchInputControlAudit.valueChanges
    //     .subscribe(() => {
    //       GridUtils.resetPaginator(this._paginatorPending);
    //       this.refreshItemsAudited(this.data);
    //     });
  
  
    }

    ngAfterViewInit(): void {
      setTimeout(() => {
  
          // const qw = this.masterService.getData(this.key, this.Mainmodule);
          // if (!qw) {
          //     this._sortPending.sort({
          //         id: this.sortColumn,
          //         start: this.sortDirection,
          //         disableClear: true,
          //     });
          // }
  
          this.searchInputControlAudit.valueChanges
              .pipe(
                  takeUntil(this._unsubscribeAll),
                  debounceTime(AppConfig.searchDelay)
              )
              .subscribe(() => {
                  GridUtils.resetPaginator(this._paginatorPending);
                this.refreshItemsAudited(this.data) 

              });
      });
  
  }

  view(record){
    this.matDialog.open(InfoWalletComponent, {
      data: { data: record, readonly: true },
      disableClose: true
    })
  }

    Audit(data: any): void {
      const label: string = 'Audit Wallet Recharge'
      this.conformationService.open({
        title: label,
        message: 'Are you sure to ' + label.toLowerCase() + ' ?'
      }).afterClosed().subscribe({
        next: (res) => {
          if (res === 'confirmed') {
            this.walletService.setRechargeAudit(data.id).subscribe({
              next: () => {
                this.alertService.showToast('success', "Document Audited", "top-right", true);
                this.refreshItemsAudited(this.data) 
              }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
            });
          }
        }
      })
    }
  
    Reject(record: any): void {
      const label: string = 'Reject Wallet Recharge'
      this.conformationService.open({
        title: label,
        message: 'Are you sure to ' + label.toLowerCase() + ' ?'
      }).afterClosed().subscribe({
        next: (res) => {
          if (res === 'confirmed') {
            this.walletService.setRechargeReject(record.id).subscribe({
              next: () => {
                this.alertService.showToast('success', "Document Audited", "top-right", true);
                this.refreshItemsAudited(this.data) 
              }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
            });
          }
        }
      })
    }


    refreshItemsAudited(data) {
      console.log("datad",data);
      this.isLoading = true;
      const filterReq = GridUtils.GetFilterReq(
        this._paginatorPending,
        this._sortPending,
        this.searchInputControlAudit.value,"recharge_for_name",0
      );
     
      filterReq['Status'] = 'audited';
      filterReq['particularId'] = data?.particularId || '';
      filterReq['mop'] = data?.mop || '';
      filterReq['psp'] = data?.psp || '';
      this.walletService.getWalletRechargeFilterList(filterReq).subscribe(
        {
          next: data => {
            this.isLoading = false;
            this.dataList = data.data;
            this._paginatorPending.length = data.total;
            this.total = data.total;
          }, error: err => {
            this.alertService.showToast('error', err);
            this.isLoading = false;
          }
        }
      );
    }

    getNodataTextAudited(): string {
      if (this.isLoading)
        return 'Loading...';
      else if (this.searchInputControlAudit.value)
        return `no search results found for \'${this.searchInputControlAudit.value}\'.`;
      else return 'No data to display';
    }

}
