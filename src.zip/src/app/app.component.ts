import { Component, Injector } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { setReflectionActivator } from './injector/reflection-injector';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { ToasterService } from './services/toaster.service';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate } from '@angular/animations';
import { MatIconModule } from '@angular/material/icon';

@Component({
    selector   : 'app-root',
    templateUrl: './app.component.html',
    styleUrls  : ['./app.component.scss'],
    standalone : true,
    imports    : [RouterOutlet, MatSnackBarModule, CommonModule,MatIconModule],
    animations: [
        trigger('slideRight', [
          transition(':enter', [
            style({ transform: 'translateY(-15px)' }),
            animate('400ms ease-out', style({ transform: 'translateY(0%)' }))
          ]),
          transition(':leave', [
            animate('400ms ease-out', style({ transform: 'translateY(15px)' }))
          ])
        ])
    ]
})
export class AppComponent
{
    showToast = false;
        toastrMsg = "";
        toastrType = "";
        toastrPosition = "";
    /**
     * Constructor
     */
    constructor(
        private injector: Injector,
        private toastr: ToasterService
    )
    {
        setReflectionActivator(this.injector);
    }
      
        ngOnInit(): void {
            this.toastr.status.subscribe((msg: string) => {
              this.toastrType = localStorage.getItem("toastrType") || "";
              this.toastrPosition = localStorage.getItem("toastrPosition") || "";
              if (msg === null) {
                this.showToast = false;
              } else {
                this.showToast = true;
                this.toastrMsg = msg;
              }
            })
        }
      
        closeToast() {
          this.showToast = false;
        }
    }

