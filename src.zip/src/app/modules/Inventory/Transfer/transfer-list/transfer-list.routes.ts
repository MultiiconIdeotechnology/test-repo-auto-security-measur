import { Routes } from "@angular/router";
import { TransferListComponent } from "./transfer-list.component";

export default [
    {
        path: '',
        component: TransferListComponent
    }
] as Routes