import { Clipboard, ClipboardModule } from '@angular/cdk/clipboard';
import { NgIf, NgFor, DatePipe, AsyncPipe, NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableDataSource } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FuseNavigationService } from '@fuse/components/navigation';
import { Routes } from 'app/common/const';
import { ClassyLayoutComponent } from 'app/layout/layouts/vertical/classy/classy.component';
import { HotelBookingService } from 'app/services/hotel-booking.service';
import { ToasterService } from 'app/services/toaster.service';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { AccountDetailsComponent } from '../../bus/account-details/account-details.component';

@Component({
  selector: 'app-hotel-booking-details',
  templateUrl: './hotel-booking-details.component.html',
  styleUrls: ['./hotel-booking-details.component.scss'],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    AsyncPipe,
    RouterModule,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatMenuModule,
    MatSlideToggleModule,
    NgxMatTimepickerModule,
    NgxMatSelectSearchModule,
    NgClass,
    ClipboardModule,
    AccountDetailsComponent,
  ]
})
export class HotelBookingDetailsComponent {

  hotelData:any;
  loading:boolean=false;
    bookingDetail:any;
    travellers = new MatTableDataSource();
    column: string[] = ['name', 'email','contact', 'passport_number'];
  jsonbook: string;

  
  constructor(
    private router : Router,
    public route: ActivatedRoute,
    private hotelBookingService: HotelBookingService,
    private clipboard: Clipboard,
    private alertService: ToasterService,
    private _fuseNavigationService: FuseNavigationService,
    private classy: ClassyLayoutComponent,
    private matDialog: MatDialog,
  ){ 

   }

  hotelRoute = Routes.booking.hotel_route;

  ngOnInit(){

    this.route.paramMap.subscribe(params => {
  
      const jsonParam = params.get('id');
      console.log(jsonParam);
      // if(jsonParam) {
        // const json = {
        //   code:jsonParam
        // }
        // this.commanService.raiseLoader(true);

        this.hotelBookingService.getHotelBookingRecord(jsonParam).subscribe({
          next: (res:any) => {
            // this.commanService.raiseLoader(false);
            this.bookingDetail = res.data;
            this.travellers.data = res.data.guests;
          },error:(err)=> {
            this.alertService.showToast('error', err);
            // this.commanService.raiseLoader(false);
          }
        });
      // }
      this.jsonbook = params.get('code');
      // this.refreshItems();
    });

    this.classy.toggleNavigation('mainNavigation');

    
  }

  copyLink(link : string): void {
    this.clipboard.copy(link);
    this.alertService.showToast('success','Copied');
  }

  close(){
    this.router.navigate([this.hotelRoute])
  }

  isSamePlanes(plan1, plan2): boolean {
    return `${plan1.airlineCode}${plan1.fareClass}${plan1.flightNumber}` === `${plan2.airlineCode}${plan2.fareClass}${plan2.flightNumber}`
  }

  getArrayWithLength(length: number): any[] {
    return new Array(length);
  }

}
