import { Routes } from "@angular/router";
import { HotelListComponent } from "./hotel-list/hotel-list.component";
import { HotelEntryNewComponent } from "./hotel-entry-new/hotel-entry-new.component";

export default [
    {
        path: '',
        component: HotelListComponent
    },
    {
        path: 'entry',
        component: HotelEntryNewComponent
    },
    {
        path: 'entry/:id',
        component: HotelEntryNewComponent
    },
    {
        path: 'entry/:id/:readonly',
        component: HotelEntryNewComponent
    },
] as Routes