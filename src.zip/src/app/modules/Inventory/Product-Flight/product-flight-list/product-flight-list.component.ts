import { Component } from '@angular/core';

@Component({
  selector: 'app-product-flight-list',
  templateUrl: './product-flight-list.component.html',
  styleUrls: ['./product-flight-list.component.scss'],
  standalone: true,
  imports: []
})
export class ProductFlightListComponent {

}
