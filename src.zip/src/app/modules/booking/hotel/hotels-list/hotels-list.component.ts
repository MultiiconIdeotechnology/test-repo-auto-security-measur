import { NgIf, NgFor, DatePipe, CommonModule, NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router, RouterOutlet } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { HotelBookingService } from 'app/services/hotel-booking.service';
import { ToasterService } from 'app/services/toaster.service';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { Linq } from 'app/utils/linq';
import { DateTime } from 'luxon';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MarkuppriceInfoComponent } from '../../flight/flight/markupprice-info/markupprice-info.component';

@Component({
  selector: 'app-hotels-list',
  templateUrl: './hotels-list.component.html',
  styleUrls: ['./hotels-list.component.scss'],
  styles: [`
  .tbl-grid {
    grid-template-columns:  40px 250px 200px 180px 180px 180px 160px 160px 200px 200px;
  }
`],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule,
    MatTooltipModule,
    NgClass,
    RouterOutlet,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    MatTabsModule,
  ],
})
export class HotelsListComponent extends BaseListingComponent {

  module_name = module_name.hotel
  dataList = [];
  total = 0;
  busFilter: any;

  columns = [
    {  key: 'booking_ref_no', name: 'Booking Ref', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true, toBooking: true},
    { key: 'status', name: 'Status', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true, toColor: true
    },
    { key: 'bookingDate', name: 'Booking Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true
    },
    { key: 'hotel_name', name: 'Hotel Name', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true
    },
    { key: 'check_in_date', name: 'Check In Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true
    },
    { key: 'check_out_date', name: 'Check Out Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: false
    },
    { key: 'from_city', name: 'From City', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false, tooltip: false
    },
    { key: 'pax', name: 'Pax', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: true, applied: false, tooltip: false
    },
    { key: 'fields', name: 'Price Detail', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: true, applied: false, tooltip: true, toview: true
    },
  ]
  cols = [];

  constructor(
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
    private toasterService: ToasterService,
    private router: Router,
    private hotelBookingService: HotelBookingService
  ) {
    super(module_name.bus);
    this.cols = this.columns.map((x) => x.key);
    this.key = this.module_name;
    this.sortColumn = 'booking_ref_no';
    this.sortDirection = 'asc';
    this.Mainmodule = this;

    this.busFilter = {
      From: '',
      To: '',
      agent_id: '',
      supplierId: '',
      Status: 'All',
      FromDate: new Date(),
      ToDate: new Date(),
    };

    this.busFilter.FromDate.setDate(1);
    this.busFilter.FromDate.setMonth(this.busFilter.FromDate.getMonth());
  }

  getFilter(): any {
    const filterReq = GridUtils.GetFilterReq(
      this._paginator,
      this._sort,
      this.searchInputControl.value
    );
    filterReq['FromDate'] = DateTime.fromJSDate(this.busFilter.FromDate).toFormat('yyyy-MM-dd');
    filterReq['ToDate'] = DateTime.fromJSDate(this.busFilter.ToDate).toFormat('yyyy-MM-dd');
    filterReq['agent_id'] = this.busFilter?.agent_id?.id || '';
    filterReq['From'] = this.busFilter?.From?.id || '';
    filterReq['To'] = this.busFilter?.To?.id || '';
    filterReq['supplierId'] = this.busFilter?.supplierId?.id || '';
    filterReq['Status'] = this.busFilter?.Status == 'All' ? '' : this.busFilter?.Status;
    return filterReq;
  }

  filter() {
    // this.matDialog
    //   .open(BusFilterComponent, {
    //     data: this.busFilter,
    //     disableClose: true,
    //   })
    //   .afterClosed()
    //   .subscribe((res) => {
    //     if (res) {
    //       this.busFilter = res;
    //       this.refreshItems();
    //     }
    //   });
  }

  viewField(data: any): void {
    if (data.fields.length == null) {
        return;
    } else {
        this.matDialog
            .open(MarkuppriceInfoComponent, {
                disableClose: true,
                data: {data:data.fields, title: "Price Details"},
            })
            .afterClosed()
            .subscribe({
                next: (value) => {},
            });
    }
  }

  viewInternal(record): void {
    Linq.recirect('/booking/hotel/details/' + record.id);
  }

  refreshItems(){
    this.isLoading = true;
        this.hotelBookingService.getHotelBookingList(this.getFilter()).subscribe({
            next: (data) => {
                this.isLoading = false;
                this.dataList = data.data;
                this._paginator.length = data.total;
            },
            error: (err) => {
            this.toasterService.showToast('error', err)
                this.isLoading = false;
            },
        });
  }

  getNodataText(): string {
    if (this.isLoading) return 'Loading...';
    else if (this.searchInputControl.value)
        return `no search results found for \'${this.searchInputControl.value}\'.`;
    else return 'No data to display';
  }

  exportExcel(): void {
    // const filterReq = GridUtils.GetFilterReq(this._paginator, this._sort, this.searchInputControl.value);
    // const req = Object.assign(filterReq);

    // req.skip = 0;
    // req.take = this._paginator.length;

    // this.busService.getBusBookingList(req).subscribe(data => {
    //   for (var dt of data.data) {
    //     dt.bookingDate = DateTime.fromISO(dt.bookingDate).toFormat('dd-MM-yyyy hh:mm a')
    //     dt.departuteDate = DateTime.fromISO(dt.departuteDate).toFormat('dd-MM-yyyy hh:mm a')
    //   }
    //   Excel.export(
    //     'Bus Booking',
    //     [
    //       { header: 'Booking Ref', property: 'booking_ref_no' },
    //       { header: 'Agency', property: 'agent_name' },
    //       { header: 'Status', property: 'status' },
    //       { header: 'TIN', property: 'tin' },
    //       { header: 'Travels', property: 'travels' },
    //       { header: 'Booking Date', property: 'bookingDate' },
    //       { header: 'Travel Date', property: 'departuteDate' },
    //       { header: 'Pax', property: 'pax' },
    //     ],
    //     data.data);
    // });
  }

}
