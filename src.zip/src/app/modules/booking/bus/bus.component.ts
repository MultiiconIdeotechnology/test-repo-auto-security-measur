import { NgIf, NgFor, DatePipe, CommonModule, NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router, RouterOutlet } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { BusService } from 'app/services/bus.service';
import { ToasterService } from 'app/services/toaster.service';
import { Excel } from 'app/utils/export/excel';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { Linq } from 'app/utils/linq';
import { DateTime } from 'luxon';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MarkuppriceInfoComponent } from '../flight/flight/markupprice-info/markupprice-info.component';
import { BusFilterComponent } from './bus-filter/bus-filter.component';

@Component({
  selector: 'app-bus',
  templateUrl: './bus.component.html',
  styleUrls: ['./bus.component.scss'],
  styles: [`
    .tbl-grid {
      grid-template-columns:  40px 200px 200px 180px 180px 180px 160px 160px 200px 180px 180px 100px 400px 180px 160px 120px;
    }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule,
    MatTooltipModule,
    NgClass,
    RouterOutlet,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    MatTabsModule,
],  

})
export class BusComponent extends BaseListingComponent {

  module_name = module_name.bus
  dataList = [];
  total = 0;
  busFilter: any;

  columns = [
    {
      key: 'supplier', name: 'Supplier', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'booking_ref_no', name: 'Booking Ref', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true,  toBooking: true
    },
    {
      key: 'status', name: 'Status', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true, toColor: true
    },
    {
      key: 'sourceCity', name: 'Source City', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'destination', name: 'Destination', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'tin', name: 'Tin', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'ticket_no', name: 'Ticket No.', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'travels', name: 'Travels', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'departuteDate', name: 'Departute Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: false
    },
    {
      key: 'bookingDate', name: 'Booking Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: false
    },
    {
      key: 'pax', name: 'Pax', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: false
    },
    {
      key: 'bus_type', name: 'Bus Type', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'payment_method', name: 'Payment Method', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'agent_name', name: 'Agent Name', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: true
    },
    {
      key: 'view', name: 'Price Detail', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: true, applied: false,  tooltip: false, toview: true
    },
  ]
  cols = [];

  constructor(
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
    private toasterService: ToasterService,
    private router: Router,
    private busService: BusService
) {
    super(module_name.bus);
    this.cols = this.columns.map((x) => x.key);
    this.key = this.module_name;
    this.sortColumn = 'booking_ref_no';
    this.sortDirection = 'asc';
    this.Mainmodule = this;

    this.busFilter = {
        From: '',
        To: '',
        agent_id: '',
        supplierId: '',
        Status: 'All',
        FromDate: new Date(),
        ToDate: new Date(),
    };

    this.busFilter.FromDate.setDate(1);
    this.busFilter.FromDate.setMonth(this.busFilter.FromDate.getMonth());
}

getFilter(): any {
  const filterReq = GridUtils.GetFilterReq(
      this._paginator,
      this._sort,
      this.searchInputControl.value
  );
  filterReq['FromDate'] = DateTime.fromJSDate(this.busFilter.FromDate).toFormat('yyyy-MM-dd');
  filterReq['ToDate'] = DateTime.fromJSDate(this.busFilter.ToDate).toFormat('yyyy-MM-dd');
  filterReq['agent_id'] = this.busFilter?.agent_id?.id || '';
  filterReq['From'] = this.busFilter?.From?.id || '';
  filterReq['To'] = this.busFilter?.To?.id || '';
  filterReq['supplierId'] = this.busFilter?.supplierId?.id || '';
  filterReq['Status'] =  this.busFilter?.Status == 'All' ? '' : this.busFilter?.Status;
  return filterReq;
}

filter() {
  this.matDialog
      .open(BusFilterComponent, {
          data: this.busFilter,
          disableClose: true,
      })
      .afterClosed()
      .subscribe((res) => {
          if (res) {
              this.busFilter = res;
              this.refreshItems();
          }
      });
}

  viewField(data: any): void {
    if (data.price_Detail.length == null) {
        return;
    } else {
        this.matDialog
            .open(MarkuppriceInfoComponent, {
                disableClose: true,
                data: {data:data.price_Detail, title: "Price Details"},
            })
            .afterClosed()
            .subscribe({
                next: (value) => {},
            });
    }
  }


  viewInternal(record): void {
    // let queryParams: any= this.router.navigate([Routes.booking.booking_details_route + '/' + record.id + '/readonly'])
    Linq.recirect('/booking/bus/details/' + record.id);
  }

  refreshItems(){
    this.isLoading = true;
        this.busService.getBusBookingList(this.getFilter()).subscribe({
            next: (data) => {
                this.isLoading = false;
                this.dataList = data.data;
                this._paginator.length = data.total;
            },
            error: (err) => {
            this.toasterService.showToast('error', err)
                this.isLoading = false;
            },
        });
  }

  getNodataText(): string {
    if (this.isLoading) return 'Loading...';
    else if (this.searchInputControl.value)
        return `no search results found for \'${this.searchInputControl.value}\'.`;
    else return 'No data to display';
  }
  

  exportExcel(): void {
    const filterReq = GridUtils.GetFilterReq(this._paginator, this._sort, this.searchInputControl.value);
    const req = Object.assign(filterReq);

    req.skip = 0;
    req.take = this._paginator.length;

    this.busService.getBusBookingList(req).subscribe(data => {
      for (var dt of data.data) {
        dt.bookingDate = DateTime.fromISO(dt.bookingDate).toFormat('dd-MM-yyyy hh:mm a')
        dt.departuteDate = DateTime.fromISO(dt.departuteDate).toFormat('dd-MM-yyyy hh:mm a')
      }
      Excel.export(
        'Bus Booking',
        [
          { header: 'Booking Ref', property: 'booking_ref_no' },
          { header: 'Agency', property: 'agent_name' },
          { header: 'Status', property: 'status' },
          { header: 'TIN', property: 'tin' },
          { header: 'Travels', property: 'travels' },
          { header: 'Booking Date', property: 'bookingDate' },
          { header: 'Travel Date', property: 'departuteDate' },
          { header: 'Pax', property: 'pax' },
        ],
        data.data);
    });
  }

}


