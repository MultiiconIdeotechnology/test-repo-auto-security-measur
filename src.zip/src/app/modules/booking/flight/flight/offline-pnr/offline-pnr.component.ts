import { NgIf, NgFor, DatePipe, CommonModule, NgClass } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterOutlet } from '@angular/router';
import { AgentService } from 'app/services/agent.service';
import { CityService } from 'app/services/city.service';
import { FlightTabService } from 'app/services/flight-tab.service';
import { ProductFixDepartureService } from 'app/services/product-fix-departure.service';
import { SupplierService } from 'app/services/supplier.service';
import { ToasterService } from 'app/services/toaster.service';
import { DateTime } from 'luxon';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { debounceTime, distinctUntilChanged, filter, Observable, of, ReplaySubject, startWith, switchMap } from 'rxjs';
// import moment from 'moment';


@Component({
  selector: 'app-offline-pnr',
  templateUrl: './offline-pnr.component.html',
  styleUrls: ['./offline-pnr.component.scss'],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule,
    MatTooltipModule,
    NgClass,
    RouterOutlet,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    MatTabsModule,
    MatSlideToggleModule,

  ],
})
export class OfflinePnrComponent {

  disableBtn: boolean = false
  SupplierList: ReplaySubject<any[]> = new ReplaySubject<any[]>();
  agentList: any[] = [];
  agentListSub: any[] = [];
  carrierList: any[] = [];
  originList: any[] = [];
  destinationList: any[] = [];
  countryList: any[] = [];
  tempcountryList: any[] = [];
  stops: any
  return_stops: any
  adult: any
  child: any
  infant: any
  formDataList: any[] = [];
  formDataListReturn: any[] = [];
  // formDataListAdult: any[] = [];
  formDataListAdult: any[] = [];
  formDataSSRs: dtoSsrs[] = [];
  formDataListChild: any[] = [];
  formDataListInfant: any[] = [];
  formDataListTraveller: any[] = [];

  combinedArray: any[];
  conbinessr: any[];
  isFirsAgent: boolean = true;
  isFirstSubAgent: boolean = true;


  // agentList: ReplaySubject<any[]> = new ReplaySubject<any[]>();


  tripList: any[] = [
    { value: 'Oneway Trip', viewValue: 'Oneway Trip' },
    { value: 'Round Trip', viewValue: 'Round Trip' },
  ];

  flightType: any[] = [
    { value: 'Economy', viewValue: 'Economy' },
    { value: 'Business', viewValue: 'Business' },
    { value: 'Premium Economy', viewValue: 'Premium Economy' },
  ];

  airlineType: any[] = [
    { value: 'LCC', viewValue: 'LCC' },
    { value: 'GDS', viewValue: 'GDS' },
  ];

  stopsList: any[] = [
    { value: '0', viewValue: 'Non-Stop' },
    { value: '1', viewValue: '1 Stop' },
    { value: '2', viewValue: '2 Stop' },
    { value: '3', viewValue: '3 Stop' },
  ];

  refNonList: any[] = [
    { value: true, viewValue: 'Refundable' },
    { value: false, viewValue: 'Non-Refundable' },
  ];

  titleType: any[] = [
    { value: 'Mr', viewValue: 'Mr' },
    { value: 'Ms', viewValue: 'Ms' },
    { value: 'Mrs', viewValue: 'Mrs' },
  ];

  title2Type: any[] = [
    { value: 'Miss', viewValue: 'Miss' },
    { value: 'Mstr', viewValue: 'Mstr' },
  ];
  isFirsTime: boolean = true;

  constructor(
    private builder: FormBuilder,
    private flighttabService: FlightTabService,
    protected alertService: ToasterService,
    private supplierService: SupplierService,
    private agentService: AgentService,
    private cityService: CityService,
    private fixDepartureService: ProductFixDepartureService,
    private matDialog: MatDialog,
  ) {
  }

  formGroup: FormGroup;

  ngOnInit(): void {

    this.formGroup = this.builder.group({
      id: [''],
      emp_id: [''],
      pnr: [''],
      gds_pnr: [''],
      trip_type: [''],
      supplier_id: [''],
      supplierFilter: [''],
      flight_type: [''],
      airline_type: [''],
      booking_date: new Date(),
      departure_date: new Date(),
      return_date: new Date(),
      adult: [0],
      child: ['0'],
      infant: ['0'],
      stops: ['0'],
      return_stops: ['0'],
      baseFare: [''],
      commission: [''],
      tds: [''],
      airlineTax: [''],
      addon_markup: [''],
      discount: [''],
      is_refundable: [''],
      agent_id: [''],
      agentfilter: [''],
      agentfilterSub: [''],
      address: [''],
      phone_number: [''],
      email: [''],
      check_in_baggage: [''],
      cabin_baggage: [''],
      is_passport_required: '',

      traveller: [this.formDataListTraveller],

      segments: [this.formDataList],
      return_segments: [this.formDataListReturn],
      carrier: [''],
      carrierFilter: [''],
      flight_number: [''],
      origin: [''],
      destination: [''],
      originfilter: [''],
      destinationfilter: [''],
      departure_date_seg: new Date(),
      return_date_seg: new Date(),
      origin_terminal: [''],
      destination_terminal: [''],

      travellers: [this.formDataListAdult, this.formDataListChild, this.formDataListInfant],
      title: [''],
      first_name: [''],
      last_name: [''],
      ticket_no: [''],
      passport_no: [''],
      baseFare_trvl: [''],
      tax: [''],
      dob: [''],
      passport_expiry_date: [''],
      passport_issuing_country: [''],
      countryfilter: [''],

    });

    this.formGroup.get('trip_type').patchValue('Oneway Trip')
    this.formGroup.get('flight_type').patchValue('Economy')
    this.formGroup.get('airline_type').patchValue('LCC')
    // this.formGroup.get('return_stops').patchValue('Non-Stop')
    this.formGroup.get('is_refundable').patchValue(true)
    this.formGroup.get('title').patchValue('Mr')
    // this.formGroup.get('passport_issuing_country').patchValue(this.countryList[0])
    this.formDataList = [{
      carrier: '',
      flight_number: '',
      origin: '',
      destination: '',
      departure_date: new Date(),
      return_date: new Date(),
      origin_terminal: '',
      destination_terminal: '',
      sSRs: [new dtoSsrs()]
    }]

    this.formDataListTraveller = [{
      address: '',
      phone_number: '',
      email: '',
      check_in_baggage: '',
      cabin_baggage: '',
      is_passport_required: ''
    }]

    this.formDataListReturn = [{
      carrier: '',
      flight_number: '',
      origin: '',
      destination: '',
      departure_date: new Date(),
      return_date: new Date(),
      origin_terminal: '',
      destination_terminal: '',
      sSRs: [new dtoSsrs()]

    }]
    this.formDataListAdult = [new dtoAdult()]
    // this.formDataListAdult = [{
    //   title: '',
    //   first_name: '',
    //   last_name: '',
    //   ticket_no: '',
    //   passport_no: '',
    //   baseFare: '',
    //   tax: '',
    //   dob: new Date(),
    //   passport_expiry_date: new Date(),
    //   passport_issuing_country: ''
    // }]
    this.formDataListChild = [new dtoAdult()
      // title: '',
      // first_name: '',
      // last_name: '',
      // ticket_no: '',
      // passport_no: '',
      // baseFare: '',
      // tax: '',
      // dob: new Date(),
      // passport_expiry_date: new Date(),
      // passport_issuing_country: ''
    ]
    this.formDataListInfant = [new dtoAdult()
      // title: '',
      // first_name: '',
      // last_name: '',
      // ticket_no: '',
      // passport_no: '',
      // baseFare: '',
      // tax: '',
      // dob: new Date(),
      // passport_expiry_date: new Date(),
      // passport_issuing_country: ''
    ]

    this.formDataSSRs = [new dtoSsrs()]

    // Value change event
    this.formGroup.get('stops').valueChanges.subscribe((value) => {
      this.getStopWiseFormData(value);
    });

    this.formGroup.get('return_stops').valueChanges.subscribe((value) => {
      // this.return_stops = value;
      // this.formDataListReturn = [];
      // for (let i = 0; i <= value; i++) {
      //   this.formDataListReturn.push({})
      // }
      this.getReturenWiseFormData(value)
    });

    this.formGroup.get('adult').valueChanges.subscribe((value) => {
      // this.adult = value;
      // this.formDataListAdult = [];
      // for (let i = 1; i <= value; i++) {
      //   this.formDataListAdult.push(new dtoAdult())
      // }
      this.getAdultFormData(value)
    });

    this.formGroup.get('child').valueChanges.subscribe((value) => {
      // this.child = value;
      // this.formDataListChild = [];
      // for (let i = 1; i <= value; i++) {
      //   this.formDataListChild.push(new dtoAdult())
      this.getChildFormData(value)
      // }
    });

    this.formGroup.get('infant').valueChanges.subscribe((value) => {
      // this.infant = value;
      // this.formDataListInfant = [];
      // for (let i = 1; i <= value; i++) {
      //   this.formDataListInfant.push(new dtoAdult())
      // }
      this.getInfantFormData(value)
    });

    /*************supplier combo**************/
    this.formGroup.get('supplierFilter').valueChanges.pipe(
      filter(search => !!search),
      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap((value: any) => {
        return this.supplierService.getSupplierCombo(value);
      })
    ).subscribe({
      next: data => {
        this.SupplierList = data
        this.formGroup.get("supplier_id").patchValue(this.SupplierList[0].id);
      }
    })

    /*************master combo**************/
    this.formGroup
      .get('agentfilter')
      .valueChanges.pipe(
        filter((search) => !!search),
        startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap((value: any) => {
          return this.flighttabService.getAgentCombo({ filter: value, MasterAgentId: '', is_master_agent: true });
        })
      )
      .subscribe({
        next: data => {
          this.agentList = data
          if (this.isFirsAgent) {
            this.formGroup.get("agent_id").patchValue(this.agentList[0].id);
            this.isFirsAgent = false;
            this.subagentComboCall()
          }
        }
      });

    this.formGroup
      .get('agentfilterSub')
      .valueChanges.pipe(
        filter((search) => !!search),
        startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap((value: any) => {
          if (this.isFirstSubAgent) {
            this.isFirstSubAgent = false;
            return new Observable<any[]>();
          }
          else
            return this.flighttabService.getAgentCombo({ filter: value, MasterAgentId: this.formGroup.get("agent_id").value, is_master_agent: false });
        })
      )
      .subscribe({
        next: data => {
          if (!this.isFirstSubAgent)
            this.agentListSub = data
          // this.formGroup.get("agent_id").patchValue(this.agentList[0].id);
        }
      });


    this.formGroup.get('agent_id').valueChanges.subscribe((value) => {
      if (value) {
        // this.updateStateSelect(value);
      }
    });

    /*************airport combo from to to**************/
    // this.formGroup
    //   .get('originfilter')
    //   .valueChanges.pipe(
    //     filter((search) => !!search),
    //     startWith(''),
    //     debounceTime(400),
    //     distinctUntilChanged(),
    //     switchMap((value: any) => {
    //       return this.flighttabService.getAirportMstCombo(value);
    //     })
    //   )
    //   .subscribe((data) => {
    //     this.originList = data;
    //     this.formGroup.get("origin").patchValue(this.originList[0].city_code);
    //   });



      // this.flighttabService.getAirportMstCombo('').subscribe((data) => {
      //   this.formDataList.map(x => {
      //     this.originList = data;
      //     x.originList = data;
      //     x.origin = data[0].id;
      //   })
      // })

    // this.formGroup
    //   .get('destinationfilter')
    //   .valueChanges.pipe(
    //     filter((search) => !!search),
    //     startWith(''),
    //     debounceTime(400),
    //     distinctUntilChanged(),
    //     switchMap((value: any) => {
    //       return this.flighttabService.getAirportMstCombo(value);
    //     })
    //   )
    //   .subscribe((data) => {
    //     this.destinationList = data
    //     this.formGroup.get("destination").patchValue(this.destinationList[0].city_code);
    //   });

      this.flighttabService.getAirportMstCombo('').subscribe((data) => {
        this.formDataList.map(x => {
          this.destinationList = data;
          x.destinationList = data;
          x.destination = data[0].city_code;
        })

        this.formDataList.map(x => {
          this.originList = data;
          x.originList = data;
          x.origin = data[0].city_code;
        })
      })

    /*************country combo**************/
    // this.formGroup
    //   .get('countryfilter')
    //   .valueChanges.pipe(
    //     filter((search) => !!search),
    //     startWith(''),
    //     debounceTime(200),
    //     distinctUntilChanged(),
    //     switchMap((value: any) => {
    //       return this.cityService.getCountryCombo(value);
    //     })
    //   )
    //   .subscribe((data) => {
    //     this.countryList = data
    //   });
    this.cityService.getCountryCombo('').subscribe((data) => {
      this.formDataListAdult.map(x => {
        this.countryList = data;
        x.countryList = data;
        x.passport_issuing_country = data[0];
      })
      this.formDataListChild.map(x => {
        this.countryList = data;
        x.countryList = data;
        x.passport_issuing_country = data[0].id;
      })
      this.formDataListInfant.map(x => {
        this.countryList = data;
        x.countryList = data;
        x.passport_issuing_country = data[0].id;
      })
    })


    this.fixDepartureService.getAirlineCombo('').subscribe((data) => {
      this.formDataList.map(x => {
        this.carrierList = data;
        x.carrierList = data;
        x.carrier = data[0].short_code;
      })
      this.formDataListReturn.map(x => {
        this.carrierList = data;
        x.carrierList = data;
        x.carrier = data[0].short_code;
      })
    })

  }

  subagentComboCall() {
    this.flighttabService.getAgentCombo({ filter: '', MasterAgentId: this.formGroup.get("agent_id").value, is_master_agent: false }).subscribe({
      next: (value: any) => {
        this.agentListSub = value;
      },
    });
  }

  searchCarrier(event, formData): void {
    if (event)
      this.fixDepartureService.getAirlineCombo(event).subscribe((data) => {
        formData.carrierList = data;
      });
  }

  searchDestination(event, formData): void {
    if (event)
      this.flighttabService.getAirportMstCombo(event).subscribe((data) => {
        formData.destinationList = data;
      });
  }

  searchOrigin(event, formData): void {
    if (event)
      this.flighttabService.getAirportMstCombo(event).subscribe((data) => {
        formData.originList = data;
      });
  }

  searchReturnCarrier(event, formData): void {
    if (event)
      this.fixDepartureService.getAirlineCombo(event).subscribe((data) => {
        formData.carrierList = data;
      });
  }
  /****/
  searchAdult(event, formData): void {
    if (event)
      this.cityService.getCountryCombo(event).subscribe((data) => {
        formData.countryList = data;
      });
  }
  searchChild(event, formData): void {
    if (event)
      this.cityService.getCountryCombo(event).subscribe((data) => {
        formData.countryList = data;
      });
  }
  searchinfant(event, formData): void {
    if (event)
      this.cityService.getCountryCombo(event).subscribe((data) => {
        formData.countryList = data;
      });
  }


  getStopWiseFormData(value): void {
    this.stops = value;
    this.formDataList = [];
    for (let i = 0; i <= value; i++) {
      this.formDataList.push({
        carrier: '',
        flight_number: '',
        origin: '',
        destination: '',
        departure_date: new Date(),
        return_date: new Date(),
        origin_terminal: '',
        destination_terminal: '',
        sSRs: [
          new dtoSsrs()
        ]
      })
    }

    this.formDataList.map(x => {
      if (!x.carrier)
        x.carrierList = this.carrierList;
      x.carrier = this.carrierList[0].short_code;
    })

    this.formDataList.map(x => {
      if (!x.destination)
        x.destinationList = this.destinationList;
      x.destination = this.destinationList[0].city_code;
    })

    this.formDataList.map(x => {
      if (!x.origin)
        x.originList = this.originList;
      x.origin = this.originList[0].city_code;
    })

  }

  getReturenWiseFormData(value): void {
    this.return_stops = value;
    this.formDataListReturn = [];
    for (let i = 0; i <= value; i++) {
      this.formDataListReturn.push({
        carrier: '',
        flight_number: '',
        origin: '',
        destination: '',
        departure_date: new Date(),
        return_date: new Date(),
        origin_terminal: '',
        destination_terminal: '',
        sSRs: [
          new dtoSsrsR()
        ]
      })
    }
    this.formDataListReturn.map(x => {
      if (!x.carrier)
        x.carrierList = this.carrierList;
      x.carrier = this.carrierList[0].short_code;
    })
  }

  getAdultFormData(value): void {
    this.adult = value;
    this.formDataListAdult = [];
    for (let i = 1; i <= value; i++) {
      this.formDataListAdult.push({
        title: this.titleType[0].value,
        first_name: '',
        last_name: '',
        ticket_no: '',
        passport_no: '',
        baseFare: '',
        tax: '',
        // dob: new Date(),
        passport_expiry_date: new Date(),
        passport_issuing_country: '',
      })
    }
    this.formDataListAdult.map(x => {
      if (!x.passport_issuing_country)
        x.countryList = this.countryList;
      x.passport_issuing_country = this.countryList[0];
    })
  }

  getChildFormData(value): void {
    this.child = value;
    this.formDataListChild = [];
    for (let i = 1; i <= value; i++) {
      this.formDataListChild.push({
        title: this.title2Type[0].value,
        first_name: '',
        last_name: '',
        ticket_no: '',
        passport_no: '',
        baseFare: '',
        tax: '',
        dob: new Date(),
        passport_expiry_date: new Date(),
        passport_issuing_country: '',
      })
    }
    this.formDataListChild.map(x => {
      if (!x.passport_issuing_country)
        x.countryList = this.countryList;
      x.passport_issuing_country = this.countryList[0];
    })
  }

  getInfantFormData(value): void {
    this.infant = value;
    this.formDataListInfant = [];
    for (let i = 1; i <= value; i++) {
      this.formDataListInfant.push({
        title: this.title2Type[0].value,
        first_name: '',
        last_name: '',
        ticket_no: '',
        passport_no: '',
        baseFare: '',
        tax: '',
        dob: new Date(),
        passport_expiry_date: new Date(),
        passport_issuing_country: '',
      })
    }
    this.formDataListInfant.map(x => {
      if (!x.passport_issuing_country)
        x.countryList = this.countryList;
      x.passport_issuing_country = this.countryList[0];
    })
  }


  addSSR(data: any) {
    // console.log("add", event);
    // this.formDataSSRs = [];
    // this.formDataSSRs.push( new dtoSsrs())

    data.sSRs.push(new dtoSsrs())
  }
  removeSSR(data: any) {
    console.log(data);
    if (data.sSRs.length > 1) {
      data.sSRs.pop();
    }
    // data.sSRs.pop()
  }

  public compareWith(v1: any, v2: any) {
    return v1 && v2 && v1.id === v2.id;
  }

  addSSRR(data: any) {
    // console.log("add", event);
    // this.formDataSSRs = [];
    // this.formDataSSRs.push( new dtoSsrs())

    data.sSRs.push(new dtoSsrsR())
  }


  save() {
    this.disableBtn = true;

    // const formattedDate = this.datePipe.transform(this.formDataListChild.dob, 'yyyy-MM-dd');

    // this.formDataList.forEach(x => {
    //     x.departure_date = moment(this.formGroup.get('departure_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('departure_date').value).format('hh:mm')
    //     x.return_date = moment(this.formGroup.get('return_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('return_date').value).format('hh:mm')
    // });
    
    // this.formDataListReturn.forEach(x => {
    //     x.departure_date = moment(this.formGroup.get('departure_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('departure_date').value).format('hh:mm')
    //     x.return_date = moment(this.formGroup.get('return_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('return_date').value).format('hh:mm')
    // });
    
    // this.formDataListAdult.forEach(x => {
    //     x.dob = moment(this.formGroup.get('dob').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('dob').value).format('hh:mm')
    //     x.passport_expiry_date = moment(this.formGroup.get('passport_expiry_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('passport_expiry_date').value).format('hh:mm')
    // });
    
    // this.formDataListChild.forEach(x => {
    //   x.dob = this.datePipe.transform(this.formDataListChild.dob, 'yyyy-MM-dd');
    //   x.passport_expiry_date = this.datePipe.transform(this.formDataListChild.passport_expiry_date, 'yyyy-MM-dd');
    // });

  //   this.formDataListInfant.forEach(x => {
  //     x.dob = moment(this.formGroup.get('dob').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('dob').value).format('hh:mm')
  //     x.passport_expiry_date = moment(this.formGroup.get('passport_expiry_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('passport_expiry_date').value).format('hh:mm')
  // });

  this.combinedArray = this.formDataListAdult.concat(this.formDataListChild, this.formDataListInfant);


    const json = this.formGroup.value
    // json['booking_date'] = moment(this.formGroup.get('booking_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('booking_date').value).format('hh:mm')
    // json['departure_date'] = moment(this.formGroup.get('departure_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('departure_date').value).format('hh:mm')
    // json['return_date'] = moment(this.formGroup.get('return_date').value).format('YYYY-MM-DD') + 'T' + moment(this.formGroup.get('return_date').value).format('hh:mm')
    json['segments'] = this.formDataList
    json['return_segments'] = this.formGroup.get('trip_type').value !== 'Oneway Trip' ? this.formDataListReturn : []
    json['traveller'] = this.formDataListTraveller
    /****adult/child/infant*****/
    json['travellers'] = this.combinedArray.filter(x => x.first_name != null && x.first_name != '')

    console.log("save", json);
    this.flighttabService.flightImport(json).subscribe({
      next: () => {
       this.disableBtn = false;
      }, error: (err) => {
        this.disableBtn = false;
        this.alertService.showToast('error', err, "top-right", true);
      }
    })
  }

}

class dtoAdult {
  title: string = '';
  first_name: string = '';
  last_name: string = '';
  ticket_no: string = '';
  passport_no: string = '';
  baseFare: string = '';
  tax: string = '';
  dob: Date = new Date();
  passport_expiry_date: Date = new Date();
  passport_issuing_country: string = '';
}

class dtoSsrs {
  type: string = '';
  item: string = '';
  amount: string = '';
}

class dtoSsrsR {
  type: string = '';
  item: string = '';
  amount: string = '';
}