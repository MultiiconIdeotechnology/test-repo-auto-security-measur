import { NgIf, NgFor, DatePipe, CommonModule } from '@angular/common';
import { Component, OnDestroy, ViewChild } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AppConfig } from 'app/config/app-config';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { WalletService } from 'app/services/wallet.service';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { DateTime } from 'luxon';
import { InfoWalletComponent } from '../info-wallet/info-wallet.component';
import { WalletFilterComponent } from '../wallet-filter/wallet-filter.component';

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss'],
  styles: [`
  .tbl-grid {
    grid-template-columns: 40px 200px 190px 160px 150px 130px 190px;
  }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatProgressBarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatMenuModule,
    MatDialogModule,
    MatTooltipModule,
    MatDividerModule,
    CommonModule,
    MatTabsModule

  ],
})
export class PendingComponent extends BaseListingComponent implements OnDestroy {

  @ViewChild('tabGroup') tabGroup;
  @ViewChild(MatPaginator) public _paginatorPending: MatPaginator;
  @ViewChild(MatSort) public _sortPending: MatSort;
  searchInputControlPending = new FormControl('');

  module_name = module_name.wallet
  dataList = [];
  total = 0;
  appConfig = AppConfig;
  data:any


  columns = [
    { key: 'reference_number', name: 'Reference Number', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, tooltip: true },
    { key: 'recharge_for_name', name: 'Recharge For', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false, tooltip: true },
    { key: 'request_date_time', name: 'Request Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'recharge_amount', name: 'Recharge Amount', is_date: false, date_formate: '', is_sortable: true, class: 'header-right-view', is_sticky: false, align: '', indicator: false },
    { key: 'filename', name: 'Attachment', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false, isicon: true },
    { key: 'mop', name: 'Mode Of Payment', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },

  ]
  cols = [];

  constructor(
    private walletService: WalletService,
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
  ) {
    super(module_name.wallet)
    this.cols = this.columns.map(x => x.key);
    this.key = this.module_name;
    this.sortColumn = 'recharge_for_name';
    this.sortDirection = 'asc';
    this.Mainmodule = this
 
  }

  ngOnInit(): void {
    // this.refreshItemsPending(this.data)

  this.searchInputControlPending.valueChanges
      .subscribe(() => {
        GridUtils.resetPaginator(this._paginatorPending);
        this.refreshItemsPending(this.data);
      });


  }

  view(record){
    this.matDialog.open(InfoWalletComponent, {
      data: { data: record, readonly: true },
      disableClose: true
    })
  }

  Audit(data: any): void {
    const label: string = 'Audit Wallet Recharge'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ?'
    }).afterClosed().subscribe({
      next: (res) => {
        if (res === 'confirmed') {
          this.walletService.setRechargeAudit(data.id).subscribe({
            next: () => {
              this.alertService.showToast('success', "Document Audited", "top-right", true);
              this.refreshItemsPending(this.data) 
            }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
          });
        }
      }
    })
  }

  Reject(record: any): void {
    const label: string = 'Reject Wallet Recharge'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ?'
    }).afterClosed().subscribe({
      next: (res) => {
        if (res === 'confirmed') {
          this.walletService.setRechargeReject(record.id).subscribe({
            next: () => {
              this.alertService.showToast('success', "Document Audited", "top-right", true);
              this.refreshItemsPending(this.data) 
            }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
          });
        }
      }
    })
  }

  refreshItemsPending(data) {
    console.log("datad",data);
    this.isLoading = true;
    const filterReq = GridUtils.GetFilterReq(
      this._paginatorPending,
      this._sortPending,
      this.searchInputControlPending.value,"recharge_for_name",0
    );
   
    filterReq['Status'] = 'pending';
    filterReq['particularId'] = data?.particularId || '';
    filterReq['mop'] = data?.mop || '';
    filterReq['psp'] = data?.psp || '';
    this.walletService.getWalletRechargeFilterList(filterReq).subscribe(
      {
        next: data => {
          this.isLoading = false;
          this.dataList = data.data;
          this._paginator.length = data.total;
          this.total = data.total;
        }, error: err => {
          this.alertService.showToast('error', err);

          this.isLoading = false;
        }
      }
    );
  }

  getNodataTextPending(): string {
    if (this.isLoading)
      return 'Loading...';
    else if (this.searchInputControlPending.value)
      return `no search results found for \'${this.searchInputControlPending.value}\'.`;
    else return 'No data to display';
  }

}
