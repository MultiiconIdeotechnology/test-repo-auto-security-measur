import { Routes } from "@angular/router";
import { VisaListComponent } from "./visa-list.component";

export default [
    {
        path: '',
        component: VisaListComponent
    }
] as Routes