export const blockUIInstance = {
    main: 'block-ui-main'
};

export const dateTimeFormats = {
    shortDate: 'dd-MM-yyyy',
    shortTime: 'hh:MM:ss',
    shortDateTime: 'dd-MM-yyyy HH:mm',
    shortDateTimess: 'dd-MM-yyyy HH:mm:ss',
    shortDateM: 'dd MMM yyyy',
    shortDateTimeM: 'dd MMM yyyy HH:mm',
    longDateTime: 'dd MMMM yyyy HH:mm',
    longDateTimess: 'dd MMMM yyyy HH:mm:ss',
    statusLogFormat: 'dd-MMM-yyyy HH:mm tt',
};

export const dateRange = {
    today: 'Today',
    last3Days: 'Last 3 Days',
    lastWeek: 'Last Week',
    lastMonth: 'Last Month',
    last3Month: 'Last 3 Month',
    last6Month: 'Last 6 Month',
    setCustomDate: 'Set Custom Date',
};

export const themes = {
    FamilyTour: 'Family Tour',
    VacationSpecial: 'Vacation Special',
    WaterSports: 'Water Sports',
    WinterSpecial: 'Winter Special',
    SummerSpecial: 'Summer Special',
    HillStation: 'Hill Station',
    LakeView: 'Lake View',
    Adventure: 'Adventure',
    HoneymoonSpecial: 'Honeymoon Special',
};

export const imageRecSize ={
    holiday: '(225px &#10005; 225px)',
    destination: '(225px &#10005; 225px)',
} 

export const imageType = {
    cover: 'Cover Photo',
    gallery: 'Gallery'
}

export const inventoryType = {
    Hotel: 'Hotel',
    Activity: 'Activity',
    Transfer: 'Transfer',
    Other: 'Other',
};

export const tripType = {
    Departure: 'Departure',
    Return: 'Return',
};

export const acceptFiles = {
    files: '.gif, .jpg, .png, .zip, .pdf'
};

export const imgExtantions = {
    jpg: 'jpg',
    jpeg: 'jpeg',
    png: 'png',
    gif: 'gif',
    svg: 'svg'
}

export const mealPlan = {
    BreakfastOnly: 'Breakfast Only [CP]',
    BreaskfastLunchDinner: 'Breakfast + Lunch/Dinner [MAP]',
    BreaskfastDinner: 'Breakfast + Dinner [MAP]',
    BreakfastLunchDinner: 'Breakfast + Lunch + Dinner [AP]',
    RoomOnly: 'Room Only [EPAI]'
}


export const yesNo = {
    yes: 'Yes',
    no: 'No'
};

export const keys = {
    permission: '3zx6QLspd25',
    permissionHash: '6964D472E7741EC05A2DF8833E39DA88',
};

export const Routes = {
    masters: {
        city_path: 'masters/city',
        city_route: '/masters/city',
        city_entry_route: '/masters/city/entry',

        compny_path: 'masters/compny',
        compny_route: 'masters/compny',

        bank_path: 'masters/bank',
        bank_route: 'masters/bank',

        currency_path: 'masters/currency',
        currency_route: '/masters/currency',

        currency_roe_path: 'masters/currency-roe',
        currency_roe_route: '/masters/currency-roe',

        destination_path: 'masters/destination',
        destination_route: '/masters/destination',
        destination_form_entry_path: 'masters/destination/entry',
        destination_form_entry_route: '/masters/destination/entry',

        department_path: 'masters/department',
        department_route: '/masters/department',

        designation_path: 'masters/designation',
        designation_route: '/masters/designation',

        employee_path: 'masters/employee',
        employee_route: '/masters/employee',
        employee_entry_route: '/masters/employee/entry',

        lead_path: 'masters/lead',
        lead_route: '/masters/lead',

        agent_path: 'masters/agent',
        agent_route: '/masters/agent',
        agent_entry_route: '/masters/agent/entry',

        whitelabel_path: 'masters/whitelabel',
        whitelabel_route: '/masters/whitelabel',

        distributor_path: 'masters/distributor',
        distributor_route: '/masters/distributor',

        supplier_path: 'masters/supplier',
        supplier_route: '/masters/supplier',

        permission_path: 'masters/permission',
        permission_route: '/masters/permission',

        permissionProfile_path: 'masters/permission-profile',
        permissionProfile_route: '/masters/permission-profile',
    },

    kyc: {
        dashboard_path: 'kyc/dashboard',
        dashboard_route: '/kyc/dashboard',

        typesofducuments_path: 'kyc/types-of-documents',
        typesofducuments_route: '/kyc/types-of-documents',

        kycprofile_path: 'kyc/kyc-profile',
        kycprofile_route: '/kyc/kyc-profile',
        kycprofile_entry_route: '/kyc/kyc-profile/entry',

        documents_path: 'kyc/documents',
        documents_route: '/kyc/documents',
        documents_entry_route: '/kyc/documents/entry',

    },

    account: {
        wallet_path: 'account/wallet',
        wallet_route: '/account/wallet',
       
        withdraw_path: 'account/withdraw',
        withdraw_route: '/account/withdraw',

    },

    inventory: {
        activity_path: 'inventory/activity',
        activity_route: '/inventory/activity',
        activity_form_entry_path: 'inventory/activity/entry',
        activity_form_entry_route: '/inventory/activity/entry',

        transfer_path: 'inventory/transfer',
        transfer_route: '/inventory/transfer',

        holiday_path: 'inventory/holiday-products',
        holiday_route: '/inventory/holiday-products',
        holiday_entry_path: 'inventory/holiday-products/entry',
        holiday_entry_route: '/inventory/holiday-products/entry',

        vehicle_path: 'inventory/vehicle',
        vehicle_route: '/inventory/vehicle',

        hotel_path: 'inventory/hotel',
        hotel_route: '/inventory/hotel',
        hotel_entry_route: '/inventory/hotel/entry',

        product_fix_departure_path: 'inventory/product-fix-departure',
        product_fix_departure_route: '/inventory/product-fix-departure',

        product_flight_path: 'inventory/product-flight',
        product_flight_route: '/inventory/product-flight',

        visa_path: 'inventory/visa',
        visa_route: '/inventory/visa',

        // markup_profile_path: 'inventory/markup-profile',
        // markup_profile_route: '/inventory/markup-profile',
        // markup_profile_entry_path: 'inventory/markup-profile/entry',
        // markup_profile_entry_route: '/inventory/markup-profile/entry',

    },

    reports: {
        // amendment_requests_path: 'reports/amendment-requests',
        // amendment_requests_route: 'reports/amendment-requests',

        ledger_path: 'reports/ledger',
        ledger_route: 'reports/ledger',

        payment_path: 'reports/account/payment',
        payment_route: 'reports/account/payment',

        receipt_path: 'reports/account/receipt',
        receipt_route: 'reports/account/receipt',
    },

    booking: {
        amendment_requests_path: 'booking/amendment-requests',
        amendment_requests_route: 'booking/amendment-requests',

        bus_path: 'booking/bus',
        bus_route: 'booking/bus',
        bus_details_route: '/booking/bus/details',

        hotel_path: 'booking/hotel',
        hotel_route: 'booking/hotel',
        hotel_details_route: '/booking/hotel/details',

        flight_path: 'booking/flight',
        flight_route: '/booking/flight',
        booking_details_route: '/booking/flight/details',
        booking_details_offline_route: '/booking/flight/offlinepnr/entry',


    },

    settings: {
        erpsettings_path: 'settings/erp',
        erpsettings_route: '/settings/erp',

        markupprofile_path: 'settings/markupprofile',
        markupprofile_route: '/settings/markupprofile',
        markupprofile_entry_path: 'settings/markupprofile/entry',
        markupprofile_entry_route: '/settings/markupprofile/entry',

        messageevents_path: 'settings/messageevents',
        messageevents_route: '/settings/messageevents',

        emailsetup_path: 'settings/emailsetup',
        emailsetup_route: '/settings/emailsetup',

        messagetemplates_path: 'settings/messagetemplates',
        messagetemplates_route: '/settings/messagetemplates',
        messagetemplates_entry_route: '/settings/messagetemplates/entry',

        defaultproductexclusions_path: 'settings/defaultproductexclusions',
        defaultproductexclusions_route: '/settings/defaultproductexclusions',

        supplierapi_path: 'settings/supplierapi',
        supplierapi_route: '/settings/supplierapi',
        
        pspsetting_path: 'settings/psp',
        pspsetting_route: '/settings/psp',

    }
}
