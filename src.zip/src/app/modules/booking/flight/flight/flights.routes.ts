import { Routes } from "@angular/router";
import { BookingDetailsComponent } from "../flight/booking-details/booking-details.component";
import { FlightComponent } from "./flight.component";
import { OfflinePnrComponent } from "./offline-pnr/offline-pnr.component";

export default [
    {
        path: '',
        component: FlightComponent
    },
    {
        path: 'details',
        component: BookingDetailsComponent
    },
    {
        path: 'details/:id',
        component: BookingDetailsComponent
    },
    {
        path: 'offlinepnr/entry',
        component: OfflinePnrComponent
    }
] as Routes