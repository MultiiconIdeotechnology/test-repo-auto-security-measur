import { Route } from '@angular/router';
import { initialDataResolver } from 'app/app.resolvers';
import { AuthGuard } from 'app/core/auth/guards/auth.guard';
import { NoAuthGuard } from 'app/core/auth/guards/noAuth.guard';
import { LayoutComponent } from 'app/layout/layout.component';
import { Routes } from './common/const';

// @formatter:off
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
export const appRoutes: Route[] = [

    // Redirect empty path to '/example'
    {path: '', pathMatch : 'full', redirectTo: 'masters/city'},

    // Redirect signed-in user to the '/example'
    //
    // After the user signs in, the sign-in page will redirect the user to the 'signed-in-redirect'
    // path. Below is another redirection for that path to redirect the user to the desired
    // location. This is a small convenience to keep all main routes together here on this file.
    {path: 'signed-in-redirect', pathMatch : 'full', redirectTo: 'masters/city'},

    // Auth routes for guests
    {
        path: '',
        canActivate: [NoAuthGuard],
        canActivateChild: [NoAuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'confirmation-required', loadChildren: () => import('app/modules/auth/confirmation-required/confirmation-required.routes')},
            {path: 'forgot-password', loadChildren: () => import('app/modules/auth/forgot-password/forgot-password.routes')},
            {path: 'reset-password', loadChildren: () => import('app/modules/auth/reset-password/reset-password.routes')},
            {path: 'sign-in', loadChildren: () => import('app/modules/auth/sign-in/sign-in.routes')},
            {path: 'sign-up', loadChildren: () => import('app/modules/auth/sign-up/sign-up.routes')}
        ]
    },

    // Auth routes for authenticated users
    {
        path: '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'sign-out', loadChildren: () => import('app/modules/auth/sign-out/sign-out.routes')},
            {path: 'unlock-session', loadChildren: () => import('app/modules/auth/unlock-session/unlock-session.routes')}
        ]
    },

    // Landing routes
    // {
    //     path: '',
    //     component: LayoutComponent,
    //     data: {
    //         layout: 'empty'
    //     },
    //     children: [
    //         {path: 'home', loadChildren: () => import('app/modules/landing/home/home.routes')},
    //     ]
    // },

    // Admin routes
    {
        path: '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            // MASTERS
            {path: Routes.masters.city_path, loadChildren: () => import('app/modules/masters/city/city-list/city-list.routes')},
            {path: Routes.masters.compny_path, loadChildren: ()=> import('app/modules/masters/compny/compny-list/compny.routes')},
            {path: Routes.masters.bank_path, loadChildren: ()=> import('app/modules/masters/bank/bank-list/bank.routes')},
            {path: Routes.masters.currency_path, loadChildren: () => import('app/modules/masters/currency/currency-list/currency-list.routes')},
            {path: Routes.masters.currency_roe_path, loadChildren: () => import('app/modules/masters/currency-roe/currency-roe-list/currency-roe.routes')},
            {path: Routes.masters.destination_path, loadChildren: () => import('app/modules/masters/destination/destination-list/destination-list.routes')},
            {path: Routes.masters.department_path, loadChildren: () => import('app/modules/masters/department/department-list/department.routes')},
            {path: Routes.masters.designation_path, loadChildren: () => import('app/modules/masters/designation/designation-list/designation-list.routes')},
            {path: Routes.masters.employee_path, loadChildren: () => import('app/modules/masters/employee/employee-list/employee-list.routes')},
            {path: Routes.masters.agent_path, loadChildren: () => import('app/modules/masters/agent/agent-list/agent-list.routes')},
            {path: Routes.masters.whitelabel_path, loadChildren: () => import('app/modules/masters/whitelabel/whitelabel-list/whitelabel-list.routes')},
            {path: Routes.masters.distributor_path, loadChildren: () => import('app/modules/masters/distributor/distributor-list/distributor-list.routes')},
            {path: Routes.masters.supplier_path, loadChildren: () => import('app/modules/masters/supplier/supplier-list/supplier-list.routes')},
            {path: Routes.masters.lead_path, loadChildren: () => import('app/modules/masters/lead/lead-list/lead-list.routes')},
            {path: Routes.masters.permission_path, loadChildren: () => import('app/modules/masters/permission/permission-list/permission-list.routes')},
            {path: Routes.masters.permissionProfile_path, loadChildren: () => import('app/modules/masters/permission-profile/permission-profile-list/permission-profile.list.routes')},

            // KYC
            {path: Routes.kyc.dashboard_path, loadChildren: () => import('app/modules/kyc/dashboard/main/main.routes')},
            {path: Routes.kyc.typesofducuments_path, loadChildren: () => import('app/modules/kyc/types-of-documents/types-of-documents-list/types-of-documents-list.routes')},
            {path: Routes.kyc.kycprofile_path, loadChildren: () => import('app/modules/kyc/kyc-profile/kyc-profile-list/kyc-profile-list.routes')},
            {path: Routes.kyc.documents_path, loadChildren: () => import('app/modules/kyc/documents/documents-list/documents.routes')},

             // Account
             {path: Routes.account.wallet_path, loadChildren: () => import('app/modules/account/wallet/wallet.routes')},
             {path: Routes.account.withdraw_path, loadChildren: () => import('app/modules/account/withdraw/withdraw.routes')},

            //Inventory
            {path: Routes.inventory.activity_path, loadChildren: () => import('app/modules/Inventory/activity/activity-list/activity-list.routes')},
            {path: Routes.inventory.transfer_path, loadChildren: () => import('app/modules/Inventory/Transfer/transfer-list/transfer-list.routes')}, 
            {path: Routes.inventory.holiday_path, loadChildren: () => import('app/modules/Inventory/Holiday/holiday-list/holiday-list.routes')}, 
            {path: Routes.inventory.vehicle_path, loadChildren: () => import('app/modules/Inventory/Vehicle/vehicle-list/vehicle-list.routes')}, 
            {path: Routes.inventory.hotel_path, loadChildren: () => import('app/modules/Inventory/hotel/hotel.routes')}, 
            {path: Routes.inventory.product_fix_departure_path, loadChildren: () => import('app/modules/Inventory/Product-Fix-Departure/product-fix-departure.routes')}, 
            {path: Routes.inventory.product_flight_path, loadChildren: () => import('app/modules/Inventory/Product-Flight/product-flight.routes')}, 
            {path: Routes.inventory.visa_path, loadChildren: () => import('app/modules/Inventory/visa/visa-list/visa.routes')}, 
            // {path: Routes.inventory.markup_profile_path, loadChildren: () => import('app/modules/Inventory/markup-profile/markup-profile-list/markup-profile-list.routes')}, 

            // REPORTS
            {path: Routes.reports.ledger_path, loadChildren: () => import('app/modules/reports/ledger/ledger-list/ledger-list.routes')},
            {path: Routes.reports.payment_path, loadChildren: () => import('app/modules/reports/account/payment-list/payment.routes')},
            {path: Routes.reports.receipt_path, loadChildren: () => import('app/modules/reports/account/receipt-list/receipt.routes')},


            // MY BOOKINGS
            {path: Routes.booking.flight_path, loadChildren: () => import('app/modules/booking/flight/flight/flights.routes')},
            {path: Routes.booking.amendment_requests_path, loadChildren: () => import('app/modules/booking/amendment-requests-list/amendment-requests-list.routes')},
            {path: Routes.booking.bus_path, loadChildren: () => import('app/modules/booking/bus/bus.routes')},
            {path: Routes.booking.hotel_path, loadChildren: () => import('app/modules/booking/hotel/hotels-list/hotel.routes')},

            // SETTINGS
            {path: Routes.settings.erpsettings_path, loadChildren: () => import('app/modules/settings/erp-settings/erp-settings.routes')},
            {path: Routes.settings.markupprofile_path, loadChildren: () => import('app/modules/settings/markup-profile/markup-profile.routes')},
            {path: Routes.settings.emailsetup_path, loadChildren: () => import('app/modules/settings/email-setup/email-setup.routes')},
            {path: Routes.settings.messageevents_path, loadChildren: () => import('app/modules/settings/message-events/message-events.routes')},
            {path: Routes.settings.messagetemplates_path, loadChildren: () => import('app/modules/settings/message-templates/message-templates.routes')},
            {path: Routes.settings.supplierapi_path, loadChildren: () => import('app/modules/settings/supplier-api/supplier-api.routes')},
            {path: Routes.settings.pspsetting_path, loadChildren: () => import('app/modules/settings/psp-setting/psp.routes')},
        ]
    },
];
