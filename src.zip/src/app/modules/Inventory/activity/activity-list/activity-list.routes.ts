import { Routes } from "@angular/router";
import { ActivityListComponent } from "./activity-list.component";
import { ActivityFormEntryComponent } from "../activity-form-entry/activity-form-entry.component";

export default [
    {
        path: '',
        component: ActivityListComponent
    },
    {
        path: 'entry',
        component: ActivityFormEntryComponent
    },
    {
        path: 'entry/:id',
        component: ActivityFormEntryComponent
    },
    {
        path: 'entry/:id/:readonly',
        component: ActivityFormEntryComponent
    }
] as Routes