import { NgIf, NgFor, NgClass, DatePipe, AsyncPipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { ToasterService } from 'app/services/toaster.service';
import { WalletService } from 'app/services/wallet.service';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { filter, startWith, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';

@Component({
  selector: 'app-wallet-filter',
  templateUrl: './wallet-filter.component.html',
  styleUrls: ['./wallet-filter.component.scss'],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    NgClass,
    DatePipe,
    AsyncPipe,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    NgxMatSelectSearchModule,
    MatDatepickerModule,
    MatTooltipModule
  ]
})
export class WalletFilterComponent {

  particularList: any[] = [];
  mopList: any[] = [];
  pspList: any[] = [];
  disableBtn: boolean = false


  constructor(
    public matDialogRef: MatDialogRef<WalletFilterComponent>,
    private builder: FormBuilder,
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
    private walletService: WalletService,
    private alertService: ToasterService,
  ) {
  }

  title = "Filter Criteria"
  btnLabel = "Apply"
  formGroup: FormGroup;

  ngOnInit(): void {
    this.formGroup = this.builder.group({
      particularfilter: [''],
      particularId: [''],
      mopfilter: [''],
      mop: [''],
      pspfilter: [''],
      psp: [''],
    });

    /********particular combo*********/
    this.formGroup
      .get('particularfilter')
      .valueChanges.pipe(
        filter((search) => !!search),
        startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap((value: any) => {
          return this.walletService.getWlCombo(value);
        })
      )
      .subscribe({
        next: data => {
          this.particularList =[];
          this.particularList.push({
            "id": "",
            "agent_id": "",
            "agency_name": "All"
          })
          this.particularList.push(...data);
          this.formGroup.get("particularId").patchValue(this.particularList[0]);
        }
      });

    /********mop combo*********/
    this.formGroup
      .get('mopfilter')
      .valueChanges.pipe(
        filter((search) => !!search),
        startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap((value: any) => {
          return this.walletService.getModeOfPaymentCombo(value);
        })
      )
      .subscribe({
        next: data => {
          this.mopList = [];
          this.mopList.push({
            "mop" : "All"
          })
          this.mopList.push(...data)
          this.formGroup.get("mop").patchValue(this.mopList[0]);
        }
      });

    /********psp combo*********/
    this.formGroup
      .get('pspfilter')
      .valueChanges.pipe(
        filter((search) => !!search),
        startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap((value: any) => {
          return this.walletService.getPaymentGatewayCombo(value);
        })
      )
      .subscribe({
        next: data => {
          this.pspList = []
          this.pspList.push({
            "id": "",
            "provider": "All"
          })
          this.pspList.push(...data)
          this.formGroup.get("psp").patchValue(this.pspList[0]);
        }
      });
  }



  apply(): void {
    const json = this.formGroup.getRawValue();
    const mop = this.formGroup.get('mop').value;
    json.mop = mop.mop === 'All' ? '' : mop.mop;
    json.particularId = json.particularId.agent_id
    json.psp = json.psp.provider === 'All' ? '' : json.psp.provider
    console.log(json);
    this.matDialogRef.close(json);
  }

  public compareWith(v1: any, v2: any) {
    return v1 && v2 && v1.id === v2.id;
  }



}
