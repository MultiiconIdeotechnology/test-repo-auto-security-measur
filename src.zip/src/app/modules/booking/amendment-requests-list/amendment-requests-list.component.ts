// import { WorkingStatusComponent } from './../../masters/employee/dialogs/working-status/working-status.component';
// import { FuseConfirmationService } from './../../../../@fuse/services/confirmation/confirmation.service';
import { DatePipe, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { AmendmentRequestsService } from 'app/services/amendment-requests.service';
import { UpdateChargeComponent } from './update-charge/update-charge.component';
import { MatDialog } from '@angular/material/dialog';
import { AmendmentRequestEntryComponent } from './amendment-request-entry/amendment-request-entry.component';
import { StatusLogComponent } from './status-log/status-log.component';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { DateTime } from 'luxon';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { Excel } from 'app/utils/export/excel';
import { mode } from 'crypto-js';
import { ToasterService } from 'app/services/toaster.service';

@Component({
    selector: 'app-amendment-requests-list',
    templateUrl: './amendment-requests-list.component.html',
    styles: [
        `
            .tbl-grid {
                grid-template-columns: 40px 220px 220px 240px 170px 170px 160px 160px 140px;
            }
        `,
    ],
    standalone: true,
    imports: [
        NgIf,
        NgFor,
        DatePipe,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatButtonModule,
        MatProgressBarModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatMenuModule,
        MatTooltipModule,
        MatDividerModule,
        NgClass,
    ],
})
export class AmendmentRequestsListComponent
    extends BaseListingComponent
    implements OnDestroy {

    module_name = module_name.amendmentRequests;
    dataList = [];
    total = 0;

    columns = [
        // {
        //     key: 'is_request_sent_to_supplier',
        //     is_date: false,
        //     date_formate: '',
        //     is_sortable: true,
        //     class: '',
        //     is_sticky: false,
        //     width: '10',
        //     align: 'center',
        //     indicator: false,
        //     is_required: false,
        //     is_boolean: false,
        //     inicon: true,
        // },
        {
            key: 'reference_no',
            name: 'Ref. No',
            is_date: false,
            date_formate: '',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: '',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'amendment_type',
            name: 'Type',
            is_date: false,
            date_formate: '',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: '',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'amendment_status',
            name: 'Status',
            is_date: false,
            date_formate: '',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: 'center',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'agency_name',
            name: 'Agent',
            is_date: false,
            date_formate: '',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: '',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'company_name',
            name: 'Supplier',
            is_date: false,
            date_formate: '',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: '',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'amendment_request_time',
            name: 'Requested On',
            is_date: true,
            date_formate: 'dd MMM yyyy hh:mm',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: 'center',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'travel_date',
            name: 'Travel Date',
            is_date: true,
            date_formate: 'dd MMM yyyy hh:mm',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: 'center',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
        {
            key: 'amendment_confirmation_time',
            name: 'Confirmed',
            is_date: true,
            date_formate: 'dd MMM yyyy hh:mm',
            is_sortable: true,
            class: '',
            is_sticky: false,
            align: 'center',
            indicator: false,
            is_required: false,
            is_boolean: false,
            inicon: false,
            tooltip: true,
        },
    ];
    cols = [];

    constructor(
        private amendmentrequestsService: AmendmentRequestsService,
        private matDialog: MatDialog,
        private toasterService: ToasterService,
        private confirmationService: FuseConfirmationService
    ) {
        super(module_name.department);
        this.cols = this.columns.map((x) => x.key);
        this.key = this.module_name;
        this.sortColumn = 'amendment_request_time';
        this.sortDirection = 'desc';
        this.Mainmodule = this;
    }

    refreshItems(): void {
        this.isLoading = true;
        this.amendmentrequestsService
            .getAirAmendmentList(this.getFilterReq())
            .subscribe({
                next: (data) => {
                    this.isLoading = false;

                    const cancel = { label: 'Cancel', icon: 'cancel', status: 'Cancelled' };
                    const reject = { label: 'Reject', icon: 'block', status: 'Rejected' };
                    const completed = { label: 'Complete', icon: 'task_alt', status: 'Completed' };
                    const sendRequest = { label: 'Send Request to Supplier', icon: 'send', status: 'Inprocess' };

                    data.data.forEach(x => {
                        x.actionStatus = [];
                        switch (x.amendment_status) {
                            case 'Pending':
                                x.actionStatus.push(cancel);
                                x.actionStatus.push(sendRequest);
                                x.class = 'text-gray-500';
                                break;
                            case 'Inprocess':
                                x.actionStatus.push(cancel);
                                x.actionStatus.push(reject);
                                x.actionStatus.push(completed);
                                x.class = 'text-orange-500';
                                break;
                            case 'Cancelled':
                                x.class = 'text-red-500';
                                break;
                            case 'Confirm':
                                x.actionStatus.push(cancel);
                                x.actionStatus.push(reject);
                                x.class = 'text-green-500';
                                break;
                            case 'Rejected':
                                x.class = 'text-red-500';
                                break;
                            case 'Completed':
                                x.class = 'text-green-500';
                                break;
                            case 'Quotation Sent':
                                x.actionStatus.push(cancel);
                                x.class = 'text-blue-500';
                                break;
                            case 'Expired':
                                x.class = 'text-red-500';
                                break;
                        }
                    })
                    this.dataList = data.data;
                    this._paginator.length = data.total;
                },
                error: (err) => {
                this.toasterService.showToast('error', err)
                    this.isLoading = false;
                },
            });
    }

    changeStatus(data, status): void {
        this.confirmationService.open({
            title: 'Status Change to ' + status.status,
            message: 'Are you sure to change status to ' + status.status + ' ?',
        }).afterClosed().subscribe(res => {
            if (res === 'confirmed')
                this.amendmentrequestsService.setAmendmentStatus(data.id, status.status).subscribe(() => { this.refreshItems(); })
        })
    }

    complete(model): void{
        const amendment = {}
        amendment['agent_id'] = model.agent_id;
        amendment['amendment_id'] = model.id;
        amendment['payment_method'] = 'Wallet';
        this.confirmationService.open( {
            title: 'Amendment process',
            message: 'Are you sure to complete this amendment process ?',
            icon: { show : true, name : 'heroicons_outline:check-circle', color: 'primary',}
        }).afterClosed().subscribe(res => {
            if (res === 'confirmed') {
                this.amendmentrequestsService.amendmentChargesDeduction(amendment).subscribe(() => { 
                    this.alertService.showToast('success', "Amendment process completed!", "top-right", true);
                    this.refreshItems(); 
                })
            }
        })
    }
  
    completeAmendment(model) {
        this.confirmationService.open({
            title: 'Amendment process',
            message: 'Are you sure to complete this amendment process ?',
            icon: { show: true, name: 'heroicons_outline:check-circle', color: 'primary', }
        }).afterClosed().subscribe(res => {
            if (res === 'confirmed') {
                //     this.alertService.showToast('success', "Amendment process completed!", "top-right", true);
                //     this.refreshItems(); 

                this.amendmentrequestsService.completeAmendment(model.id).subscribe({
                    next: (value: any) => {
                        console.log(value);
                        this.alertService.showToast('success', "Amendment process completed!", "top-right", true);
                        this.refreshItems();
                    },error :(err)  =>{
                     this.alertService.showToast('error', err, "top-right", true);
                    },
                })

                // this.amendmentrequestsService.completeAmendment(model.id).subscribe(() => {
                //     console.log("ghjfhjgj")
                //     this.alertService.showToast('success', "Amendment process completed!", "top-right", true);
                //     this.refreshItems();
                // })
            }
        })
    }

    showUpdateCharge(data): boolean {
        return ['Inprocess', 'Quotation Sent'].includes(data.amendment_status);
    }

    updateCharge(model): void {
        this.matDialog.open(UpdateChargeComponent, {
            data: model,
            disableClose: true
        }).afterClosed().subscribe(res => {
            if (res) {
                this.alertService.showToast('success', "Charge has been Updated!", "top-right", true);
                this.refreshItems();
            }
        })
    }



    statusLogs(model): void {
        this.matDialog.open(StatusLogComponent, {
            data: model,
            disableClose: true
        })
    }

    view(record): void {
        this.matDialog.open(AmendmentRequestEntryComponent, {
            data: { data: record, readonly: true, showUpdateCharge: this.showUpdateCharge(record) },
            disableClose: true
        }).afterClosed().subscribe(res => {
            if (res) {
                this.refreshItems();
            }
        })
    }

    getNodataText(): string {
        if (this.isLoading) return 'Loading...';
        else if (this.searchInputControl.value)
            return `no search results found for \'${this.searchInputControl.value}\'.`;
        else return 'No data to display';
    }

    ngOnDestroy(): void {
        this.masterService.setData(this.key, this);
    }

    exportExcel(): void {
        const filterReq = GridUtils.GetFilterReq(this._paginator, this._sort, this.searchInputControl.value);
        const req = Object.assign(filterReq);

        req.skip = 0;
        req.take = this._paginator.length;


        this.amendmentrequestsService.getAirAmendmentList(req).subscribe(data => {
            for (var dt of data.data) {
                dt.amendment_request_time = DateTime.fromISO(dt.amendment_request_time).toFormat('dd-MM-yyyy hh:mm a')
                dt.travel_date = DateTime.fromISO(dt.travel_date).toFormat('dd-MM-yyyy hh:mm a')
            }
            Excel.export(
                'Amendment Booking',
                [
                    { header: 'Ref No.', property: 'reference_no' },
                    { header: 'Status', property: 'amendment_status' },
                    { header: 'Type', property: 'amendment_type' },
                    { header: 'Request Time', property: 'amendment_request_time' },
                    { header: 'Travel Date', property: 'travel_date' },
                    { header: 'Agent', property: 'agency_name' },
                    { header: 'Supplier', property: 'company_name' },
                    { header: 'Confirmed', property: 'amendment_confirmation_time' },
                ],
                data.data);
        });
    }
}
