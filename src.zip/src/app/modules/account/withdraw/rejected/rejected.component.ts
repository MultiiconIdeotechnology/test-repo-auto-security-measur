import { NgIf, NgFor, NgClass, DatePipe, AsyncPipe } from '@angular/common';
import { Component, OnDestroy, ViewChild } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterModule } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AppConfig } from 'app/config/app-config';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { MasterService } from 'app/services/master.service';
import { ToasterService } from 'app/services/toaster.service';
import { WithdrawService } from 'app/services/withdraw.service';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { DateTime } from 'luxon';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { takeUntil, debounceTime, Subject } from 'rxjs';
import { InfoWithdrawComponent } from '../info-withdraw/info-withdraw.component';

@Component({
  selector: 'app-wrejected',
  templateUrl: './rejected.component.html',
  styleUrls: ['./rejected.component.scss'],
  styles: [`
  .tbl-grid {
    grid-template-columns: 40px 200px 90px 120px 150px 130px 130px 170px 100px 160px 110px 130px 190px;
  }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    NgClass,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    DatePipe,
    AsyncPipe,
    NgxMatSelectSearchModule,
    NgxMatTimepickerModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatTooltipModule,
    MatMenuModule,
    MatTabsModule,
    MatPaginatorModule,
    MatSortModule

  ],
})
export class WRejectedComponent {

  @ViewChild('tabGroup') tabGroup;

  @ViewChild(MatPaginator) public _paginatorPending: MatPaginator;
  @ViewChild(MatSort) public _sortPending: MatSort;
  searchInputControlRejected = new FormControl('');

  Mainmodule: any;
  isLoading = false;
  public _unsubscribeAll: Subject<any> = new Subject<any>();
  public key: any;
  public sortColumn: any;
  public sortDirection: any;

  module_name = module_name.wallet
  dataList = [];
  total = 0;
  appConfig = AppConfig;
  data: any


  columns = [
    { key: 'agent_name', name: 'Agent', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: true, tooltip: true },
    { key: 'withdraw_currency', name: 'Currency', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false },
    { key: 'withdraw_status', name: 'Status', is_date: false, date_formate: '', is_sortable: true, class: 'header-left-view', is_sticky: false, align: '', indicator: false },
    { key: 'withdraw_amount', name: 'Amount', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false },
    { key: 'reject_by', name: 'Reject By', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false, tooltip: true },
    { key: 'audit_by', name: 'Audit By', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'agent_remark', name: 'Agent Remark', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'is_audited', name: 'Is Audited', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false, is_boolean: true },
    { key: 'audit_date_time', name: 'Audit Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'is_rejected', name: 'Is Rejected', is_date: false, date_formate: '', is_sortable: true, class: 'header-center-view', is_sticky: false, align: '', indicator: false, is_boolean: true },
    { key: 'reject_date_time', name: 'Reject Date', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },
    { key: 'reject_remark', name: 'Reject Remark', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, align: '', indicator: false },

  ]
  cols = [];
  protected masterService: MasterService;


  constructor(
    private withdrawService: WithdrawService,
    private conformationService: FuseConfirmationService,
    private alertService: ToasterService,
    private matDialog: MatDialog,
  ) {
    // super(module_name.wallet)
    this.cols = this.columns.map(x => x.key);
    this.key = this.module_name;
    this.sortColumn = 'withdraw_status';
    this.sortDirection = 'asc';
    this.Mainmodule = this

  }

  ngOnInit(): void {

    // this.searchInputControlRejected.valueChanges
    //     .subscribe(() => {
    //       GridUtils.resetPaginator(this._paginatorPending);
    //       this.refreshItemsRejected(this.data);
    //     });


  }
  ngAfterViewInit(): void {
    setTimeout(() => {

      // const qw = this.masterService.getData(this.key, this.Mainmodule);
      // if (!qw) {
      //   this._sortPending.sort({
      //     id: this.sortColumn,
      //     start: this.sortDirection,
      //     disableClear: true,
      //   });
      // }

      this.searchInputControlRejected.valueChanges
        .pipe(
          takeUntil(this._unsubscribeAll),
          debounceTime(AppConfig.searchDelay)
        )
        .subscribe(() => {
          GridUtils.resetPaginator(this._paginatorPending);
          this.refreshItemsRejected(this.data)
        });
    });

  }


  view(record) {
    this.matDialog.open(InfoWithdrawComponent, {
      data: { data: record, readonly: true },
      disableClose: true
    })
  }

  Audit(data: any): void {
    const label: string = 'Audit Wallet Withdraw'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ?'
    }).afterClosed().subscribe({
      next: (res) => {
        if (res === 'confirmed') {
          this.withdrawService.setWithdrawAudit(data.id).subscribe({
            next: () => {
              this.alertService.showToast('success', "Wallet Withdraw Audited", "top-right", true);
              this.refreshItemsRejected(this.data)
            }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
          });
        }
      }
    })
  }

  Reject(record: any): void {
    const label: string = 'Reject Wallet Withdraw'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ?'
    }).afterClosed().subscribe({
      next: (res) => {
        if (res === 'confirmed') {
          this.withdrawService.setWithdrawReject(record.id).subscribe({
            next: () => {
              this.alertService.showToast('success', "Wallet Withdraw Audited", "top-right", true);
              this.refreshItemsRejected(this.data)
            }, error: (err) => this.alertService.showToast('error', err, "top-right", true)
          });
        }
      }
    })
  }


  refreshItemsRejected(data) {
    this.isLoading = true;
    const filterReq = GridUtils.GetFilterReq(
      this._paginatorPending,
      this._sortPending,
      this.searchInputControlRejected.value, "withdraw_status", 0
    );
    filterReq['status'] = 'rejected';
    filterReq['FromDate'] = data?.FromDate || DateTime.fromJSDate(new Date()).toFormat('yyyy-MM-dd')
    filterReq['ToDate'] = data?.ToDate || DateTime.fromJSDate(new Date()).toFormat('yyyy-MM-dd')
    filterReq['agent_id'] = data?.agent_id || '';
    this.withdrawService.getWalletWithdrawList(filterReq).subscribe(
      {
        next: data => {
          this.isLoading = false;
          this.dataList = data.data;
          this._paginatorPending.length = data.total;
          this.total = data.total;
        }, error: err => {
          this.alertService.showToast('error', err, "top-right", true)
          this.isLoading = false;
        }
      }
    );
  }

  getNodataTextRejected(): string {
    if (this.isLoading)
      return 'Loading...';
    else if (this.searchInputControlRejected.value)
      return `no search results found for \'${this.searchInputControlRejected.value}\'.`;
    else return 'No data to display';
  }

}
