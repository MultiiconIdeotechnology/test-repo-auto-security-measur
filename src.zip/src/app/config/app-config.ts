export const AppConfig = {
    pageSizeOptions: [5, 10, 15, 25, 100],
    pageSize: 15,
    searchDelay: 500,
    showFirstLastButtons: true,
};
