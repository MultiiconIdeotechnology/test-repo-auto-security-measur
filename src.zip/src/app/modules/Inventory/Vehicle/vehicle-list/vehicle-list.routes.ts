import { Routes } from "@angular/router";
import { VehicleListComponent } from "./vehicle-list.component";

export default [
    {
        path: '',
        component: VehicleListComponent
    }
] as Routes