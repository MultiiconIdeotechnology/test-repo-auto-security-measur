import { Routes } from "@angular/router";
import { WalletComponent } from "./wallet.component";

export default [
    {
        path: '',
        component: WalletComponent
    }
] as Routes