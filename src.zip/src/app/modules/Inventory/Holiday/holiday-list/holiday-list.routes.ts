import { Routes } from "@angular/router";
import { ViewDetailsComponent } from "../view-details/view-details.component";
import { HolidayListComponent } from "./holiday-list.component";
// import { HolidayEntryComponent } from "../holiday-entry/holiday-entry.component";

export default [
    {
        path: '',
        component: HolidayListComponent
    },
    {
        path     : 'view-details',
        component: ViewDetailsComponent,
    }
    // {
    //     path: 'entry',
    //     component: HolidayEntryComponent
    // },
    // {
    //     path: 'entry/:id',
    //     component: HolidayEntryComponent
    // },
    // {
    //     path: 'entry/:id/:readonly',
    //     component: HolidayEntryComponent
    // }
] as Routes