/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';
import { Routes } from 'app/common/const';

export const defaultNavigation: FuseNavigationItem[] = [
    {
        id: 'masters',
        title: 'Masters',
        type: 'group',
        pid: 'MAIN_MASTERS_VIEW',
        icon: 'heroicons_outline:squares-2x2',
        children: [
            {
                id: 'master.city',
                title: 'City',
                type: 'basic',
                pid: 'MASTER_CITY_VIEW',
                icon: 'heroicons_outline:building-office-2',
                link: Routes.masters.city_route
            },
            {
                id: 'master.Company',
                title: 'Company',
                type: 'basic',
                pid: 'MASTER_CITY_VIEW',
                icon: 'heroicons_outline:building-storefront',
                link: Routes.masters.compny_route
            },
            {
                id: 'master.Bank',
                title: 'Bank',
                type: 'basic',
                pid: 'MASTER_CITY_VIEW',
                icon: 'heroicons_outline:building-office',
                link: Routes.masters.bank_route
            },
            {
                id: 'master.currency',
                title: 'Currency',
                type: 'basic',
                pid: 'MASTER_CURRENCY_VIEW',
                icon: 'heroicons_outline:currency-rupee',
                link: Routes.masters.currency_route
            },
            {
                id: 'master.currency',
                title: 'Currency ROE',
                type: 'basic',
                pid: 'MASTER_CURRENCY_VIEW',
                icon: 'heroicons_outline:currency-rupee',
                link: Routes.masters.currency_roe_route
            },
            {
                id: 'master.destination',
                title: 'Destination',
                type: 'basic',
                pid: 'MASTER_DESTINATION_VIEW',
                icon: 'heroicons_outline:globe-asia-australia',
                link: Routes.masters.destination_route
            },
            {
                id: 'master.department',
                title: 'Department',
                type: 'basic',
                pid: 'MASTER_DEPARTMENT_VIEW',
                icon: 'mat_outline:group_work',
                link: Routes.masters.department_route
            },
            {
                id: 'master.designation',
                title: 'Designation',
                type: 'basic',
                pid: 'MASTER_DESIGNATION_VIEW',
                icon: 'mat_outline:supervised_user_circle',
                link: Routes.masters.designation_route
            },
            {
                id: 'master.employee',
                title: 'Employee',
                type: 'basic',
                pid: 'MASTER_EMPLOYEE_VIEW',
                icon: 'heroicons_outline:user',
                link: Routes.masters.employee_route
            },
            {
                id: 'master.lead',
                title: 'Lead',
                type: 'basic',
                pid: 'MASTER_LEADS_VIEW',
                icon: 'mat_outline:supervisor_account',
                link: Routes.masters.lead_route
            },
            {
                id: 'master.agent',
                title: 'Agent',
                type: 'basic',
                pid: 'MASTER_AGENT_VIEW',
                icon: 'mat_outline:contact_page',
                link: Routes.masters.agent_route
            },
            {
                id: 'master.whitelabel',
                title: 'Whitelabel',
                type: 'basic',
                pid: 'MASTER_WHITELABLE_VIEW',
                icon: 'mat_outline:branding_watermark',
                link: Routes.masters.whitelabel_route
            },
            {
                id: 'master.distributor',
                title: 'Distributor',
                type: 'basic',
                pid: 'MASTER_DISTRIBUTOR_VIEW',
                icon: 'mat_outline:hail',
                link: Routes.masters.distributor_route
            },
            {
                id: 'master.supplier',
                title: 'Supplier',
                type: 'basic',
                pid: 'MASTER_SUPPLIER_VIEW',
                icon: 'mat_outline:perm_contact_calendar',
                link: Routes.masters.supplier_route
            },
            {
                id: 'master.permission',
                title: 'Permission Master',
                type: 'basic',
                pid: 'MASTER_PERMISSION_VIEW',
                icon: 'mat_outline:bookmark',
                link: Routes.masters.permission_route
            },
            {
                id: 'master.permission-profile',
                title: 'Permission Profile',
                type: 'basic',
                pid: 'MASTER_PERMISSIONPROFILE_VIEW',
                icon: 'mat_outline:verified_user',
                link: Routes.masters.permissionProfile_route
            },
        ]
    },
    {
        id: 'kyc',
        title: 'KYC',
        type: 'group',
        icon: 'mat_outline:fingerprint',
        children: [
            {
                id: 'kyc.dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'heroicons_outline:rectangle-group',
                link: Routes.kyc.dashboard_route
            },
            {
                id: 'kyc.types_of_documents',
                title: 'Types of Documents',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-document',
                link: Routes.kyc.typesofducuments_route
            },
            {
                id: 'kyc.kyc_profile',
                title: 'KYC Profile',
                type: 'basic',
                icon: 'heroicons_outline:identification',
                link: Routes.kyc.kycprofile_route
            },
            {
                id: 'master.documents',
                title: 'Documents',
                type: 'basic',
                icon: 'heroicons_outline:document-text',
                link: Routes.kyc.documents_route
            },
        ]
    },
    {
        id: 'account',
        title: 'Account',
        type: 'group',
        icon: 'heroicons_outline:building-library',
        children: [
            {
                id: 'account.wallet',
                title: 'Wallet',
                type: 'basic',
                icon: 'heroicons_outline:wallet',
                link: Routes.account.wallet_route
            },
            {
                id: 'account.withdraw',
                title: 'Withdraw',
                type: 'basic',
                icon: 'heroicons_outline:arrow-down-on-square-stack',
                link: Routes.account.withdraw_route
            },
        ]
    },
    {
        id: 'inventory',
        title: 'Inventory',
        type: 'group',
        icon: 'mat_outline:inventory',
        children: [
            {
                id: 'inventory.activity',
                title: 'Activity',
                type: 'basic',
                icon: 'mat_outline:rowing',
                link: Routes.inventory.activity_route
            },
            {
                id: 'inventory.transfer',
                title: 'Transfer Activity',
                type: 'basic',
                icon: 'mat_outline:transfer_within_a_station',
                link: Routes.inventory.transfer_route
            },
            {
                id: 'inventory.holiday',
                title: 'Holiday Products',
                type: 'basic',
                icon: 'mat_outline:holiday_village',
                link: Routes.inventory.holiday_route
            },
            {
                id: 'inventory.vehicle',
                title: 'Vehicle',
                type: 'basic',
                icon: 'mat_outline:local_taxi',
                link: Routes.inventory.vehicle_route
            },
            {
                id: 'inventory.hotel',
                title: 'Hotel',
                type: 'basic',
                icon: 'heroicons_outline:building-office-2',
                link: Routes.inventory.hotel_route
            },
            {
                id: 'inventory.visa',
                title: 'Visa',
                type: 'basic',
                icon: 'heroicons_outline:newspaper',
                link: Routes.inventory.visa_route
            },
            // {
            //     id: 'inventory.markupProfile',
            //     title: 'Markup Profile',
            //     type: 'basic',
            //     icon: 'heroicons_outline:queue-list',
            //     link: Routes.inventory.markup_profile_route
            // },
            // {
            //     id: 'inventory.productfixdeparture',
            //     title: 'Product Fix Departure',
            //     type: 'basic',
            //     icon: 'heroicons_outline:building-office-2',
            //     link: Routes.inventory.product_fix_departure_route
            // },
            // {
            //     id: 'inventory.productflight',
            //     title: 'Product Flight',
            //     type: 'basic',
            //     icon: 'heroicons_outline:building-office-2',
            //     link: Routes.inventory.product_flight_route
            // },
        ]
    },
    {
        id: 'reports',
        title: 'Reports',
        type: 'group',
        icon: 'heroicons_outline:document-text',
        children: [
            // {
            //     id: 'reports.amendment_requests',
            //     title: 'Amendment Requests',
            //     type: 'basic',
            //     icon: 'heroicons_outline:document-text',
            //     link: Routes.reports.amendment_requests_route
            // },
            {
                id: 'reports.ledger',
                title: 'Agent Ledger',
                type: 'basic',
                icon: 'heroicons_outline:document-text',
                link: Routes.reports.ledger_route
            },
            {
                id: 'reports.account',
                title: 'Account',
                type: 'collapsable',
                icon: 'heroicons_outline:building-library',
                // link: Routes.reports.account_route
                children: [
                    {
                        id: 'reports.payments',
                        title: 'Payment',
                        type: 'basic',
                        link: Routes.reports.payment_path
                    },
                    {
                        id: 'reports.receipts',
                        title: 'Receipt',
                        type: 'basic',
                        link: Routes.reports.receipt_path
                    },
                ]
            },
        ]
        },
        {
            id: 'booking',
            title: 'Bookings',
            type: 'group',
            icon: 'heroicons_outline:document-text',
            children: [
                {
                    id: 'reports.flight',
                    title: 'Flight',
                    type: 'collapsable',
                    icon: 'flight',
                    children: [
                        {
                            id: 'reports.amendment_requests',
                            title: 'Flight Bookings',
                            type: 'basic',
                            link: Routes.booking.flight_route
                        },
                        {
                            id: 'reports.amendment_requests',
                            title: 'Amendment Requests',
                            type: 'basic',
                            link: Routes.booking.amendment_requests_route
                        },
                    ]
                },
                {
                    id: 'reports.bus',
                    title: 'Bus',
                    type: 'basic',
                    icon: 'directions_bus',
                    link: Routes.booking.bus_route
                },
                {
                    id: 'reports.hotel',
                    title: 'Hotel',
                    type: 'basic',
                    icon: 'heroicons_outline:building-office-2',
                    link: Routes.booking.hotel_route
                },
            ]
            },
    {
        id: 'settings',
        title: 'Settings',
        type: 'group',
        icon: 'mat_outline:settings',
        children: [
            {
                id: 'settings.erp',
                title: 'ERP Settings',
                type: 'basic',
                icon: 'mat_outline:settings',
                link: Routes.settings.erpsettings_route
            },
            {
                id: 'settings.markupprofile',
                title: 'Markup Profile',
                type: 'basic',
                icon: 'mat_outline:payments',
                link: Routes.settings.markupprofile_route
            },
            {
                id: 'settings.emailsetup',
                title: 'Email Setup',
                type: 'basic',
                icon: 'mat_outline:mail',
                link: Routes.settings.emailsetup_route
            },
            {
                id: 'settings.messageevents',
                title: 'Message Events',
                type: 'basic',
                icon: 'mat_outline:speaker_notes',
                link: Routes.settings.messageevents_route
            },
            {
                id: 'settings.messagetemplates',
                title: 'Message Templates',
                type: 'basic',
                icon: 'mat_outline:drafts',
                link: Routes.settings.messagetemplates_route
            },
            {
                id: 'settings.supplierapi',
                title: 'Supplier API',
                type: 'basic',
                icon: 'mat_outline:perm_contact_calendar',
                link: Routes.settings.supplierapi_route
            },
            {
                id: 'settings.erp',
                title: 'PSP',
                type: 'basic',
                icon: 'mat_outline:settings',
                link: Routes.settings.pspsetting_route
            },
        ]
    }
];
export const compactNavigation: FuseNavigationItem[] = [
    // {
    //     id: 'masters',
    //     title: 'Masters',
    //     type: 'aside',
    //     pid: 'MAIN_MASTERS_VIEW',
    //     icon: 'heroicons_outline:squares-2x2',
    //     link: '/masters',
    //     children: [
    //         {
    //             id: 'master.city',
    //             title: 'City',
    //             type: 'basic',
    //             pid: 'MASTER_CITY_VIEW',
    //             icon: 'heroicons_outline:building-office-2',
    //             link: Routes.masters.city_route
    //         },
    //         {
    //             id: 'master.currency',
    //             title: 'Currency',
    //             type: 'basic',
    //             pid: 'MASTER_CURRENCY_VIEW',
    //             icon: 'heroicons_outline:currency-rupee',
    //             link: Routes.masters.currency_route
    //         },
    //         {
    //             id: 'master.destination',
    //             title: 'Destination',
    //             type: 'basic',
    //             pid: 'MASTER_DESTINATION_VIEW',
    //             icon: 'heroicons_outline:globe-asia-australia',
    //             link: Routes.masters.destination_route
    //         },
    //         {
    //             id: 'master.department',
    //             title: 'Department',
    //             type: 'basic',
    //             pid: 'MASTER_DEPARTMENT_VIEW',
    //             icon: 'mat_outline:group_work',
    //             link: Routes.masters.department_route
    //         },
    //         {
    //             id: 'master.designation',
    //             title: 'Designation',
    //             type: 'basic',
    //             pid: 'MASTER_DESIGNATION_VIEW',
    //             icon: 'mat_outline:supervised_user_circle',
    //             link: Routes.masters.designation_route
    //         },
    //         {
    //             id: 'master.employee',
    //             title: 'Employee',
    //             type: 'basic',
    //             pid: 'MASTER_EMPLOYEE_VIEW',
    //             icon: 'heroicons_outline:user',
    //             link: Routes.masters.employee_route
    //         },
    //         {
    //             id: 'master.lead',
    //             title: 'Lead',
    //             type: 'basic',
    //             pid: 'MASTER_LEADS_VIEW',
    //             icon: 'mat_outline:supervisor_account',
    //             link: Routes.masters.lead_route
    //         },
    //         {
    //             id: 'master.agent',
    //             title: 'Agent',
    //             type: 'basic',
    //             pid: 'MASTER_AGENT_VIEW',
    //             icon: 'mat_outline:contact_page',
    //             link: Routes.masters.agent_route
    //         },
    //         {
    //             id: 'master.whitelabel',
    //             title: 'Whitelabel',
    //             type: 'basic',
    //             pid: 'MASTER_WHITELABLE_VIEW',
    //             icon: 'mat_outline:branding_watermark',
    //             link: Routes.masters.whitelabel_route
    //         },
    //         {
    //             id: 'master.distributor',
    //             title: 'Distributor',
    //             type: 'basic',
    //             pid: 'MASTER_DISTRIBUTOR_VIEW',
    //             icon: 'mat_outline:hail',
    //             link: Routes.masters.distributor_route
    //         },
    //         {
    //             id: 'master.supplier',
    //             title: 'Supplier',
    //             type: 'basic',
    //             pid: 'MASTER_SUPPLIER_VIEW',
    //             icon: 'mat_outline:perm_contact_calendar',
    //             link: Routes.masters.supplier_route
    //         },
    //         {
    //             id: 'master.permission',
    //             title: 'Permission Master',
    //             type: 'basic',
    //             pid: 'MASTER_PERMISSION_VIEW',
    //             icon: 'mat_outline:bookmark',
    //             link: Routes.masters.permission_route
    //         },
    //         {
    //             id: 'master.permission-profile',
    //             title: 'Permission Profile',
    //             type: 'basic',
    //             pid: 'MASTER_PERMISSIONPROFILE_VIEW',
    //             icon: 'mat_outline:verified_user',
    //             link: Routes.masters.permissionProfile_route
    //         },
    //     ]
    // },
    // {
    //     id: 'kyc',
    //     title: 'KYC',
    //     type: 'aside',
    //     icon: 'mat_outline:fingerprint',
    //     link: '/kyc',
    //     children: [
    //         {
    //             id: 'kyc.dashboard',
    //             title: 'Dashboard',
    //             type: 'basic',
    //             icon: 'heroicons_outline:rectangle-group',
    //             link: Routes.kyc.dashboard_route
    //         },
    //         {
    //             id: 'kyc.types_of_documents',
    //             title: 'Types of Documents',
    //             type: 'basic',
    //             icon: 'heroicons_outline:clipboard-document',
    //             link: Routes.kyc.typesofducuments_route
    //         },
    //         {
    //             id: 'kyc.kyc_profile',
    //             title: 'KYC Profile',
    //             type: 'basic',
    //             icon: 'heroicons_outline:identification',
    //             link: Routes.kyc.kycprofile_route
    //         },
    //         {
    //             id: 'master.documents',
    //             title: 'Documents',
    //             type: 'basic',
    //             icon: 'heroicons_outline:document-text',
    //             link: Routes.kyc.documents_route
    //         },
    //     ]
    // },
    // {
    //     id: 'inventory',
    //     title: 'Inventory',
    //     type: 'aside',
    //     icon: 'mat_outline:inventory',
    //     link: '/inventory',
    //     children: [
    //         {
    //             id: 'inventory.activity',
    //             title: 'Activity',
    //             type: 'basic',
    //             icon: 'mat_outline:rowing',
    //             link: Routes.inventory.activity_route
    //         },
    //         {
    //             id: 'inventory.transfer',
    //             title: 'Transfer Activity',
    //             type: 'basic',
    //             icon: 'mat_outline:transfer_within_a_station',
    //             link: Routes.inventory.transfer_route
    //         },
    //         {
    //             id: 'inventory.holiday',
    //             title: 'Holiday Products',
    //             type: 'basic',
    //             icon: 'mat_outline:holiday_village',
    //             link: Routes.inventory.holiday_route
    //         },
    //         {
    //             id: 'inventory.vehicle',
    //             title: 'Vehicle',
    //             type: 'basic',
    //             icon: 'mat_outline:local_taxi',
    //             link: Routes.inventory.vehicle_route
    //         },
    //         {
    //             id: 'inventory.hotel',
    //             title: 'Hotel',
    //             type: 'basic',
    //             icon: 'heroicons_outline:building-office-2',
    //             link: Routes.inventory.hotel_route
    //         },
    //         // {
    //         //     id: 'inventory.markupProfile',
    //         //     title: 'Markup Profile',
    //         //     type: 'basic',
    //         //     icon: 'heroicons_outline:queue-list',
    //         //     link: Routes.inventory.markup_profile_route
    //         // },
    //         // {
    //         //     id: 'inventory.productfixdeparture',
    //         //     title: 'Product Fix Departure',
    //         //     type: 'basic',
    //         //     icon: 'heroicons_outline:building-office-2',
    //         //     link: Routes.inventory.product_fix_departure_route
    //         // },
    //         // {
    //         //     id: 'inventory.productflight',
    //         //     title: 'Product Flight',
    //         //     type: 'basic',
    //         //     icon: 'heroicons_outline:building-office-2',
    //         //     link: Routes.inventory.product_flight_route
    //         // },
    //     ]
    // },
    // {
    //     id: 'settings',
    //     title: 'Settings',
    //     type: 'aside',
    //     icon: 'mat_outline:settings',
    //     link: '/settings',
    //     children: [
    //         {
    //             id: 'settings.erp',
    //             title: 'ERP Settings',
    //             type: 'basic',
    //             icon: 'mat_outline:settings',
    //             link: Routes.settings.erpsettings_route
    //         },
    //         {
    //             id: 'settings.markupprofile',
    //             title: 'Markup Profile',
    //             type: 'basic',
    //             icon: 'mat_outline:payments',
    //             link: Routes.settings.markupprofile_route
    //         },
    //         {
    //             id: 'settings.emailsetup',
    //             title: 'Email Setup',
    //             type: 'basic',
    //             icon: 'mat_outline:mail',
    //             link: Routes.settings.emailsetup_route
    //         },
    //         {
    //             id: 'settings.messageevents',
    //             title: 'Message Events',
    //             type: 'basic',
    //             icon: 'mat_outline:speaker_notes',
    //             link: Routes.settings.messageevents_route
    //         },
    //         {
    //             id: 'settings.messagetemplates',
    //             title: 'Message Templates',
    //             type: 'basic',
    //             icon: 'mat_outline:drafts',
    //             link: Routes.settings.messagetemplates_route
    //         },
    //         {
    //             id: 'settings.supplierapi',
    //             title: 'Supplier API',
    //             type: 'basic',
    //             icon: 'mat_outline:perm_contact_calendar',
    //             link: Routes.settings.supplierapi_route
    //         },
    //     ]
    // }
];
export const futuristicNavigation: FuseNavigationItem[] = [
    {
        id: 'example',
        title: 'Example',
        type: 'basic',
        icon: 'heroicons_outline:chart-pie',
        link: '/example'
    }
];
export const horizontalNavigation: FuseNavigationItem[] = [
    {
        id: 'example',
        title: 'Example',
        type: 'basic',
        icon: 'heroicons_outline:chart-pie',
        link: '/example'
    }
];
