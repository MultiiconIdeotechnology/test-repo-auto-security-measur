import { Component } from '@angular/core';

@Component({
  selector: 'app-product-flight-entry',
  templateUrl: './product-flight-entry.component.html',
  styleUrls: ['./product-flight-entry.component.scss']
})
export class ProductFlightEntryComponent {

}
