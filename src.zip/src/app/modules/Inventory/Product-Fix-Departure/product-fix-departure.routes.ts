import { Routes } from "@angular/router";
import { ProductFixDepartureComponent } from "./product-fix-departure/product-fix-departure.component";

export default [
    {
        path: '',
        component: ProductFixDepartureComponent
    },
    // {
    //     path: 'entry',
    //     component: ProductPricingEntryComponent
    // }
] as Routes