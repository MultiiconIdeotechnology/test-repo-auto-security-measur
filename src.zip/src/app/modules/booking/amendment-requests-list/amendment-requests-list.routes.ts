import { Routes } from "@angular/router";
import { AmendmentRequestsListComponent } from "./amendment-requests-list.component";

export default [
    {
        path: '',
        component: AmendmentRequestsListComponent
    }
] as Routes