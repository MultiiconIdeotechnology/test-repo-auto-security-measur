export class JsonFile {
    public fileName: string;
    public fileType: string;
    public base64: any;
}
