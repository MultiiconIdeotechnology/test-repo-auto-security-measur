import { Routes } from "@angular/router";
import { ProductFlightListComponent } from "./product-flight-list/product-flight-list.component";

export default [
    {
        path: '',
        component: ProductFlightListComponent
    },
    // {
    //     path: 'entry',
    //     component: ProductPricingEntryComponent
    // }
] as Routes