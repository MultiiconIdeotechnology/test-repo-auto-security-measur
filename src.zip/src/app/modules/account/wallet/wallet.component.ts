import { NgIf, NgFor, DatePipe, CommonModule } from '@angular/common';
import { Component, OnDestroy, ViewChild } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabGroup, MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AppConfig } from 'app/config/app-config';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { module_name } from 'app/security';
import { WalletService } from 'app/services/wallet.service';
import { GridUtils } from 'app/utils/grid/gridUtils';
import { takeUntil, debounceTime } from 'rxjs';
import { AuditedComponent } from './audited/audited.component';
import { PendingComponent } from './pending/pending.component';
import { RejectedComponent } from './rejected/rejected.component';
import { WalletFilterComponent } from './wallet-filter/wallet-filter.component';
import { WalletInfoComponent } from './wallet-info/wallet-info.component';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.scss'],
  styles: [`
  .tbl-grid {
    grid-template-columns: 40px 200px 190px 160px 150px 130px 190px;
  }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    DatePipe,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatProgressBarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatMenuModule,
    MatDialogModule,
    MatTooltipModule,
    MatDividerModule,
    CommonModule,
    MatTabsModule,
    PendingComponent,
    AuditedComponent,
    RejectedComponent,

  ],
})
export class WalletComponent extends BaseListingComponent implements OnDestroy {

  @ViewChild('pending') pending: PendingComponent;
  @ViewChild('audited') audited: AuditedComponent;
  @ViewChild('rejected') rejected: RejectedComponent;
  public apiCalls: any = {};
  tabName: any
  tabNameStr: any = 'Pending'
  tab: string = 'Pending';
  isSecound: boolean = true
  isThird: boolean = true
  filterData:any

  @ViewChild(MatPaginator) public _paginatorPending: MatPaginator;
  @ViewChild(MatSort) public _sortPending: MatSort;
  searchInputControlPending = new FormControl('');

  @ViewChild(MatPaginator) public _paginatorAudit: MatPaginator;
  @ViewChild(MatSort) public _sortPaid: MatSort;
  searchInputControlAudit = new FormControl('');

  @ViewChild(MatPaginator) public _paginatorRejected: MatPaginator;
  @ViewChild(MatSort) public _sortRejected: MatSort;
  searchInputControlRejected = new FormControl('');

  dataPending:any
  dataAudited:any
  dataRejected:any

  constructor(
    private walletService: WalletService,
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
  ) {
    super(module_name.withdraw)
    this.sortColumn = 'request_date_time';
    this.sortDirection = 'asc';
    this.Mainmodule = this
  }

  ngOnInit(): void {

    this.searchInputControlPending.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(AppConfig.searchDelay)
      )
      .subscribe((value) => {
        this.pending.searchInputControlPending.patchValue(value)
      });

    this.searchInputControlAudit.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(AppConfig.searchDelay)
      )
      .subscribe((value) => {
        this.audited.searchInputControlAudit.patchValue(value)
      });

    this.searchInputControlRejected.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(AppConfig.searchDelay)
      )
      .subscribe((value) => {
        this.rejected.searchInputControlRejected.patchValue(value)
      });

  }

  public tabChanged(event: any): void {

    const tabName = event?.tab?.ariaLabel;
    this.tabNameStr = tabName
    this.tabName = tabName

    switch (tabName) {
      case 'Pending':
        this.tab = 'Pending';
        break;

      case 'Audited':
        this.tab = 'Audited';
        if (this.isSecound) {
          this.audited.refreshItemsAudited(this.dataAudited)
          this.isSecound = false
        }
        break;

      case 'Rejected':
        this.tab = 'Rejected';
        if (this.isThird) {
          this.rejected.refreshItemsRejected(this.dataRejected)
          this.isThird = false
        }
        break;
    }
  }

  private ifNotThenCall(call: string, callback: () => void): void {
    if (!this.apiCalls[call]) {
      this.apiCalls[call] = false;
      callback();
    }
  }

  ngAfterViewInit(): void {
    this.apiCalls = {
      Pending: false,
      Audited: false,
      Rejected: false,
    };
  }

  filter(): void {
    this.matDialog.open(WalletFilterComponent, {
      data: null,
      disableClose: true
    }).afterClosed().subscribe(res => {
      this.filterData = res
      this.pending.refreshItemsPending(this.filterData)
      this.audited.refreshItemsAudited(this.filterData)
      this.rejected.refreshItemsRejected(this.filterData)
    })
  }

  refreshItemsTab(): void {
    if (this.tab == 'Audited')
      this.audited.refreshItemsAudited(this.dataAudited)
    else if (this.tab == 'Rejected')
      this.rejected.refreshItemsRejected(this.dataRejected)
    else
      this.pending.refreshItemsPending(this.dataPending)
  }
}
