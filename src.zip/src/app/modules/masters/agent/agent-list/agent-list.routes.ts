import { Routes } from "@angular/router";
import { AgentListComponent } from "./agent-list.component";
import { AgentEntryComponent } from "../agent-entry/agent-entry.component";

export default [
    {
        path: '',
        component: AgentListComponent
    },
    {
        path: 'entry',
        component: AgentEntryComponent
    },
    {
        path: 'entry/:id',
        component: AgentEntryComponent
    },
    {
        path: 'entry/:id/:readonly',
        component: AgentEntryComponent
    },
    {
        path: 'entry/:id/:readonly/:lead',
        component: AgentEntryComponent
    },
] as Routes