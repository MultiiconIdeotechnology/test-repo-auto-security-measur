import { Routes } from "@angular/router";
import { WithdrawListComponent } from "./withdraw-list/withdraw-list.component";

export default [
    {
        path: '',
        component: WithdrawListComponent
    }
] as Routes