import { Routes } from "@angular/router";
import { TypesOfDocumentsListComponent } from "./types-of-documents-list.component";

export default [
    {
        path: '',
        component: TypesOfDocumentsListComponent
    }
] as Routes