import { Routes } from "@angular/router";
import { HotelBookingDetailsComponent } from "../hotel-booking-details/hotel-booking-details.component";
import { HotelsListComponent } from "./hotels-list.component";

export default [
    {
        path: '',
        component: HotelsListComponent
    },
    {
        path: 'details',
        component: HotelBookingDetailsComponent
    },
    {
        path: 'details/:id',
        component: HotelBookingDetailsComponent
    }
] as Routes

