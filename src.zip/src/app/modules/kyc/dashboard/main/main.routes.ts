import { Routes } from "@angular/router";
import { MainComponent } from "./main.component";

export default [
    {
        path: '',
        component: MainComponent
    }
] as Routes