import { Routes } from 'app/common/const';
import { Router } from '@angular/router';
import { module_name } from 'app/security';
import { Component } from '@angular/core';
import { CommonModule, DatePipe, NgClass, NgFor, NgIf } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { EmployeeDialogComponent } from '../employee-dialog/employee-dialog.component';
import { BaseListingComponent } from 'app/form-models/base-listing';
import { KycInfoComponent } from '../kyc-info/kyc-info.component';
import { BlockReasonComponent } from '../../supplier/block-reason/block-reason.component';
import { MarkupProfileDialogeComponent } from '../markup-profile-dialoge/markup-profile-dialoge.component';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AgentService } from 'app/services/agent.service';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { SetKycProfileComponent } from '../set-kyc-profile/set-kyc-profile.component';
import { SetCurrencyComponent } from '../set-currency/set-currency.component';
import { AgentFilterComponent } from '../agent-filter/agent-filter.component';
import { GridUtils } from 'app/utils/grid/gridUtils';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styles: [`
  .tbl-grid {
    grid-template-columns:  40px 110px 250px 250px 200px 100px 200px 200px 150px 150px;
  }
  `],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    NgClass,
    DatePipe,
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatProgressBarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatMenuModule,
    MatDialogModule,
    MatTooltipModule,
    MatDividerModule,
  ]
})
export class AgentListComponent extends BaseListingComponent {
  module_name = module_name.agent
  agentFilter: any;
  dataList = [];
  total = 0;

  columns = [
    { key: 'agent_code', name: 'Agent Code', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, indicator: true, is_boolean: false, tooltip: false },
    { key: 'agency_name', name: 'Agent', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: true },
    { key: 'email_address', name: 'Email', is_date: false, date_formate: '', is_sortable: false, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: true },
    { key: 'mobile_number', name: 'Mobile', is_date: false, date_formate: '', is_sortable: false, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: false },
    { key: 'base_currency', name: 'Currency', is_date: false, date_formate: '', is_sortable: false, class: 'header-center-view', is_sticky: false, indicator: false, is_boolean: false, tooltip: false },
    { key: 'relation_manager_name', name: 'Relationship Manager ', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: false },
    { key: 'city_name', name: 'City', is_date: false, date_formate: '', is_sortable: true, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: true },
    { key: 'web_last_login_time', name: 'Last Login', is_date: false, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: false },
    { key: 'entry_date_time', name: 'Signup', is_date: true, date_formate: 'dd MMM yyyy hh:mm', is_sortable: true, class: '', is_sticky: false, indicator: false, is_boolean: false, tooltip: false },
  ]
  cols = [];

  constructor(
    private agentService: AgentService,
    private conformationService: FuseConfirmationService,
    private matDialog: MatDialog,
    private router: Router,
  ) {
    super(module_name.agent)
    this.cols = this.columns.map(x => x.key);
    this.key = this.module_name;
    this.sortColumn = 'entry_date_time';
    this.sortDirection = 'desc';
    this.Mainmodule = this

    this.agentFilter = {
      relationmanagerId: '',
      currencyId: '',
      cityId: '',
      markupProfileId: '',
      kycProfileId: '',
      is_blocked: '',
    }
  }

  getFilter(): any {
    const filterReq = GridUtils.GetFilterReq(
      this._paginator,
      this._sort,
      this.searchInputControl.value
    );
    filterReq["relationmanagerId"] = this.agentFilter?.relationmanagerId?.id || "";
    filterReq["currencyId"] = this.agentFilter?.currencyId?.id || "";
    filterReq["cityId"] = this.agentFilter?.cityId?.id || "";
    filterReq["markupProfileId"] = this.agentFilter?.markupProfileId?.id || "";
    filterReq["kycProfileId"] = this.agentFilter?.kycProfileId?.id || "";
    filterReq["blocked"] = this.agentFilter?.blocked == "All" ? "" : this.agentFilter?.blocked;
    return filterReq;
  }

  filter() {
    this.matDialog.open(AgentFilterComponent, {
      data: this.agentFilter,
      disableClose: true,
    }).afterClosed().subscribe(res => {
      if (res) {
        this.agentFilter = res;
        this.refreshItems();
      }
    })
  }

  refreshItems(): void {
    this.isLoading = true;
    this.agentService.getAgentList(this.getFilter()).subscribe({
      next: data => {
        this.isLoading = false;
        this.dataList = data.data;
        this.total = data.total;
      }, error: err => {
        this.alertService.showToast('error', err, 'top-right', true);
        this.isLoading = false;
      }
    })
  }

  autologin(record: any) {

    this.agentService.autoLogin(record.id).subscribe({
      next: data => {
        window.open(data.url + 'sign-in/' + data.code);
      }, error: err => {
        this.alertService.showToast('error', err)
      }
    })

  }

  createInternal(model): void {
    this.router.navigate([Routes.masters.agent_entry_route])
  }

  editInternal(record): void {
    this.router.navigate([Routes.masters.agent_entry_route + '/' + record.id])
  }

  viewInternal(record): void {
    this.router.navigate([Routes.masters.agent_entry_route + '/' + record.id + '/readonly'])
  }

  deleteInternal(record): void {
    const label: string = 'Delete Agent'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ' + record.agency_name + ' ?'
    }).afterClosed().subscribe(res => {
      if (res === 'confirmed') {
        this.agentService.delete(record.id).subscribe({
          next: () => {
            this.alertService.showToast('success', "Agent has been deleted!", "top-right", true);
            this.refreshItems()
          },
          error: (err) => {
            this.alertService.showToast('error', err, 'top-right', true);
          },
        })
      }
    })
  }

  setBlockUnblock(record): void {
    // if (!Security.hasNewEntryPermission(this.module)) {
    //     this.alertService.error('Permission Denied.');
    //     return;
    // }
    if (record.is_blocked) {
      const label: string = 'Unblock Agent'
      this.conformationService.open({
        title: label,
        message: 'Are you sure to ' + label.toLowerCase() + ' ' + record.agency_name + ' ?'
      }).afterClosed().subscribe(res => {
        if (res === 'confirmed') {
          this.agentService.setBlockUnblock(record.id).subscribe({
            next: () => {
              record.is_blocked = !record.is_blocked;
              this.alertService.showToast('success', "Agent has been Unblock!", "top-right", true);
            },
            error: (err) => {
              this.alertService.showToast('error',err,'top-right',true);
          },
          })
        }
      })
    } else {
      this.matDialog.open(BlockReasonComponent, {
        data: record,
        disableClose: true
      }).afterClosed().subscribe(res => {
        if (res) {
          this.agentService.setBlockUnblock(record.id, res).subscribe({
            next: () => {
              record.is_blocked = !record.is_blocked;
              this.alertService.showToast('success', "Agent has been Block!", "top-right", true);
            },
            error: (err) => {
              this.alertService.showToast('error',err,'top-right',true);
          },
          })
        }
      })
    }
  }

  resetPassword(record): void {

  }

  relationahipManager(record): void {
    this.matDialog.open(EmployeeDialogComponent, {
      data: record,
      disableClose: true
    }).afterClosed().subscribe(res => {
      if (res) {
        this.agentService.setRelationManager(record.id, res.empId).subscribe({
          next: () => {
            // record.is_blocked = !record.is_blocked;
            this.alertService.showToast('success', "Relationship Manager Changed!");
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
            
        },
        })
      }
    })
  }

  setKYCVerify(record): void {
    this.matDialog.open(KycInfoComponent, {
      data: { record: record, agent: true },
      disableClose: true
    }).afterClosed().subscribe(res => {
      if (res) {
        // this.agentService.setMarkupProfile(record.id, res.transactionId).subscribe({
        //   next: () => {
        //     // record.is_blocked = !record.is_blocked;
        //     this.alertService.showToast('success', "The markup profile has been set", "top-right", true);
        //   }
        // })
      }
    })
  }

  setMarkupProfile(record): void {
    // if (!Security.hasNewEntryPermission(this.module)) {
    //     this.alertService.error('Permission Denied.');
    //     return;
    // }
    this.matDialog.open(MarkupProfileDialogeComponent, {
      data: record,
      disableClose: true
    }).afterClosed().subscribe(res => {
      if (res) {
        this.agentService.setMarkupProfile(record.id, res.transactionId).subscribe({
          next: () => {
            // record.is_blocked = !record.is_blocked;
            this.alertService.showToast('success', "The markup profile has been set!", "top-right", true);
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
          
        },
        })
      }
    })
  }

  setEmailVerify(record): void {
    const label: string = record.is_email_verified ? 'Unverify Email' : 'Verify Email'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ' + record.email_address + ' ?'
    }).afterClosed().subscribe(res => {
      if (res === 'confirmed') {
        this.agentService.setEmailVerify(record.id).subscribe({
          next: () => {
            record.is_email_verified = !record.is_email_verified;
            if (record.is_email_verified) {
              this.alertService.showToast('success', "Email has been verified!", "top-right", true);
            }
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
           
        },
        })
      }
    })
  }

  setMobileVerify(record): void {
    const label: string = record.is_mobile_verified ? 'Unverify Mobile' : 'Verify Mobile'
    this.conformationService.open({
      title: label,
      message: 'Are you sure to ' + label.toLowerCase() + ' ' + record.mobile_number + ' ?'
    }).afterClosed().subscribe(res => {
      if (res === 'confirmed') {
        this.agentService.setMobileVerify(record.id).subscribe({
          next: () => {
            record.is_mobile_verified = !record.is_mobile_verified;
            if (record.is_mobile_verified) {
              this.alertService.showToast('success', "Mobile number has been verified1", "top-right", true);
            }
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
            
        },
        })
      }
    })
  }

  setCurrency(record): void {
    this.matDialog.open(SetCurrencyComponent, {
      data: record,
      disableClose: true
    }).afterClosed().subscribe(res => {
      if (res) {
        this.agentService.setBaseCurrency(record.id, res.base_currency_id).subscribe({
          next: () => {
            this.alertService.showToast('success', "The base currency has been set!", "top-right", true);
            this.refreshItems();
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
          
        },
        })
      }
    });
  }

  kycProfile(record): void {

    this.matDialog.open(SetKycProfileComponent, {
      data: record,
      disableClose: true
    }).afterClosed().subscribe(res => {
      if (res) {

        this.agentService.mapkycProfile(record.id, res.kyc_profile_id).subscribe({
          next: () => {
            // record.is_blocked = !record.is_blocked;
            this.alertService.showToast('success', "KYC Profile has been Added!", "top-right", true);
            record.kyc_profile_id = res.kyc_profile_id;
          },
          error: (err) => {
            this.alertService.showToast('error',err,'top-right',true);
          
        },
        })
      }
    })
  }

  convertWl(record): void {
  }

  getNodataText(): string {
    if (this.isLoading)
      return 'Loading...';
    else if (this.searchInputControl.value)
      return `no search results found for \'${this.searchInputControl.value}\'.`;
    else return 'No data to display';
  }

  ngOnDestroy(): void {
    this.masterService.setData(this.key, this)
  }
}
