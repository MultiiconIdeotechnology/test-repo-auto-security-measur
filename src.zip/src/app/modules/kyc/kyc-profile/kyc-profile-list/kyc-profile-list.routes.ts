import { Routes } from "@angular/router";
import { KycProfileListComponent } from "./kyc-profile-list.component";
import { KycEntryComponent } from "../kyc-entry/kyc-entry.component";

export default [
    {
        path: '',
        component: KycProfileListComponent
    },
    {
        path: 'entry',
        component: KycEntryComponent
    },
    {
        path: 'entry/:id',
        component: KycEntryComponent
    },
    {
        path: 'entry/:id/:readonly',
        component: KycEntryComponent
    }
] as Routes